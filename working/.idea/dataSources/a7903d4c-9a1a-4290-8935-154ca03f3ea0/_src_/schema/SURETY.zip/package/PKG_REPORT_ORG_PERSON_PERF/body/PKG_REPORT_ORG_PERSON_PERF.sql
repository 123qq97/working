CREATE PACKAGE BODY PKG_REPORT_ORG_PERSON_PERF
AS  PROCEDURE PRO_REPORT_ORG_PERSON_PERF
(
       IN_QUERY_BEGIN_DATE IN VARCHAR,      /*输入-开始日期YYYY-mm-dd*/
       IN_QUERY_END_DATE IN VARCHAR,        /*输入-结束日期YYYY-mm-dd*/
       IN_QUERY_ORG_ID IN VARCHAR,          /*输入-组织ID*/
       IN_QUERY_PERSON_ID IN VARCHAR,       /*输入-客户经理ID*/
       IN_LONG_NUMBERS IN VARCHAR,          /*输入-长编码，多个用逗号隔开*/
       OUT_DATASET OUT GET_CURSOR           /*输出-结果集*/
)
IS
   V_SQL  CLOB;                             /*变量-执行总SQL*/
   V_WITH_SQL  CLOB;                        /*变量-临时变量视图SQL*/
   V_WITH_DATA_SQL  CLOB;                   /*变量-临时变量视图SQL*/
   V_ROW_RESULT_SQL  CLOB;                  /*变量-行结果集SQL*/
   V_WHERE_AUTH_SQL CLOB;                   /*变量-组织查询条件*/
   V_WHERE_PERSON_SQL CLOB;                 /*变量-人员查询条件*/

   GLOBAL_OUT_RETURN VARCHAR2(1000);      /*异常描述*/
   GLOBAL_ERROR_EXCEPTION EXCEPTION;      /*申明异常*/
   GLOBAL_ERROR_CODE      NUMBER;         /*异常编码*/
   GLOBAL_ERROR_MSG       VARCHAR2(1000); /*异常信息*/
   GLOBAL_FLAG           VARCHAR2(10);    /*标记*/
BEGIN
   DBMS_OUTPUT.ENABLE(BUFFER_SIZE => NULL);

    /**查询条件*/
    V_WHERE_AUTH_SQL := '';
    V_WHERE_PERSON_SQL :='';
    IF IN_QUERY_ORG_ID IS NOT NULL THEN
       V_WHERE_AUTH_SQL := V_WHERE_AUTH_SQL || ' AND ORG.FLONG_NUMBER LIKE (SELECT O.FLONG_NUMBER FROM T_ERP_ORG O WHERE O.FID= ''' || IN_QUERY_ORG_ID || ''')  || ''%''';
    END IF;
    IF IN_QUERY_PERSON_ID IS NOT NULL THEN
       V_WHERE_PERSON_SQL := V_WHERE_PERSON_SQL || ' AND T.PERSON_ID =''' || IN_QUERY_PERSON_ID || '''';
    END IF;



   V_WITH_SQL := '
              WITH
                /*权限*/
                V_T_AUTH AS (
                    SELECT  FLONG_NUMBER AS   LONG_NUMBER
                                FROM ( SELECT  DISTINCT
                                                SUBSTR(T.CA,INSTR(T.CA, '','', 1, C.LV) + 1,
                                                       INSTR(T.CA, '','', 1, C.LV + 1) -(INSTR(T.CA, '','', 1, C.LV) + 1)) AS FLONG_NUMBER
                                       FROM (SELECT '','' || STR || '','' AS CA,LENGTH(STR || '','') -NVL(LENGTH(REPLACE(STR, '','')), 0) AS CNT FROM ((SELECT  '''|| IN_LONG_NUMBERS ||''' AS STR FROM DUAL))) T,
                                            (SELECT LEVEL LV FROM DUAL CONNECT BY LEVEL <= 1000) C
                                       WHERE C.LV <= T.CNT )
             ),
             /**用于计算往期的订单*/
             V_T_ORDER_LAST AS (
                    SELECT V_ORDER.FORDER_ID FROM V_ORDER_REPAYMENT_REDEEM V_ORDER
                    WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0
                       AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''YYYY-MM-DD'') < ''' || IN_QUERY_BEGIN_DATE ||'''
             ),
             /**往期-退费订单ID*/
             V_T_ORDER_REFUND_LAST AS (
                    SELECT REFUND.FORDER_ID FROM T_FN_FIN_REFUND_FEE_DETAILS REFUND
                    WHERE REFUND.FHANDLE_STATUS = ''FINISH_HANDLE''
                     AND TO_CHAR(REFUND.FREFUND_DATE,''YYYY-MM-DD'') < ''' || IN_QUERY_BEGIN_DATE ||'''
             ),
             /*咨询费  IS_OUT_BUSS 0=内单 1 = 外单*/
             V_T_ADVICE_FEE AS (
                    SELECT ''ADVICE'' AS DATA_TYPE , V_ORDER.FORDER_ID , V_ORDER.FORG_ID AS FMANAGER_ORG_ID , V_ORDER.PARTNER_ID AS FMANAGER_ID ,V_ORDER.IS_OUT_BUSS_NEW AS IS_OUT_BUSS ,V_ORDER.FFUND_TYPE,
                           /*担保咨询费*/
                           SUM(FEE.FADVICE_TOTAL_FEE + FEE.FOVERCHARGE_TOTAL_FEE - FEE.FPOUNDAGE_TOTAL_FEE) AS ADVICE_TOTAL_FEE
                    FROM V_ORDER_REPAYMENT_REDEEM V_ORDER
                         LEFT JOIN T_FN_FIN_FEE_GENERAL FEE ON V_ORDER.FORDER_ID = FEE.FORDER_ID
                    WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0
                       AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                       AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                    GROUP BY V_ORDER.FORDER_ID , V_ORDER.FORG_ID , V_ORDER.PARTNER_ID , V_ORDER.IS_OUT_BUSS_NEW ,V_ORDER.FFUND_TYPE
             ),
            /**风控审查费-撤单咨询费*/
            V_T_REVOKE_FEE AS (
                  SELECT ''REVOKE'' AS DATA_TYPE,FORDER_ID,FMANAGER_ORG_ID,FMANAGER_ID,IS_OUT_BUSS,FFUND_TYPE,SUM(REVOKE_MONEY) AS ADVICE_TOTAL_FEE
                  FROM(
                    SELECT OB.FORDER_ID,OB.FMANAGER_ORG_ID , OB.FMANAGER_ID ,
                           CASE WHEN G.FGUARANTEE_TYPE = ''INTERNAL'' THEN 0 ELSE 1 END  AS  IS_OUT_BUSS,
                           BT.FFUND_TYPE,
                           FEE.FTOTAL_FEE AS REVOKE_MONEY
                    FROM T_FN_FIN_FEE_GENERAL FEE
                         LEFT JOIN T_RISK_REVOKE_ORDER RO ON RO.FORDER_ID = FEE.FORDER_ID
                         LEFT JOIN T_SURETY_ORDER_BASE OB   ON OB.FORDER_ID = FEE.FORDER_ID
                         LEFT JOIN T_SURETY_GUARANTEE G ON G.FID = OB.FORDER_ID
                         LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON BT.FID = OB.FBIZ_ID
                         LEFT JOIN V_ORDER_REVOKE_CAN_REFUND RCR ON RCR.FORDER_ID = OB.FORDER_ID
                         LEFT JOIN T_FN_FIN_REFUND_FEE_DETAILS REFUND ON REFUND.FORDER_ID = FEE.FORDER_ID
                    WHERE RO.FIS_CHARGE = ''YES''
                          AND RO.FAPPROVAL_STATE = ''PASS''
                          AND (REFUND.FHANDLE_STATUS = ''FINISH_HANDLE'' OR RCR.CAN_REFUND_MONEY = 0)
                          AND TO_CHAR(RO.FFINISH_TIME,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                          AND TO_CHAR(RO.FFINISH_TIME,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                    ) T GROUP BY  FORDER_ID , FMANAGER_ORG_ID , FMANAGER_ID , IS_OUT_BUSS,FFUND_TYPE
            ),
             /*返佣*/
             V_T_REBATE_FEE AS (
                    SELECT ''REBATE'' AS DATA_TYPE , V_ORDER.FORDER_ID ,V_ORDER.FORG_ID AS FMANAGER_ORG_ID , V_ORDER.PARTNER_ID AS FMANAGER_ID ,V_ORDER.IS_OUT_BUSS_NEW AS IS_OUT_BUSS ,V_ORDER.FFUND_TYPE,
                           NVL(SUM(R.FREBATE),0) AS REBATE
                    FROM T_SURETY_G_LOAN_DETAILS R
                         LEFT JOIN V_ORDER_REPAYMENT_REDEEM V_ORDER   ON V_ORDER.FORDER_ID = R.FGUARANTEE_ID
                   WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0
                     AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                     AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                     GROUP BY V_ORDER.FORDER_ID , V_ORDER.FORG_ID , V_ORDER.PARTNER_ID , V_ORDER.IS_OUT_BUSS_NEW ,V_ORDER.FFUND_TYPE
             ),
             /*当期展期费*/
             V_T_DELAY_FEE AS (
                    SELECT ''DELAY'' AS DATA_TYPE ,FORDER_ID,FMANAGER_ORG_ID,FMANAGER_ID,IS_OUT_BUSS,FFUND_TYPE,
                           SUM(FFEE_MONEY) AS DELAY_FEE
                    FROM(
                           SELECT OB.FORDER_ID,OB.FMANAGER_ORG_ID , OB.FMANAGER_ID ,
                             CASE WHEN G.FGUARANTEE_TYPE = ''INTERNAL'' THEN 0 ELSE 1 END  AS  IS_OUT_BUSS,
                             BT.FFUND_TYPE,
                             FFEE_MONEY
                          FROM T_FN_FIN_FEE_DETAILS FD
                               LEFT JOIN T_SURETY_ORDER_BASE OB   ON OB.FORDER_ID = FD.FORDER_ID
                               LEFT JOIN T_SURETY_GUARANTEE G ON G.FID = OB.FORDER_ID
                               LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON BT.FID = OB.FBIZ_ID
                          WHERE FD.FFEE_TYPE = ''DELAY_FEE''
                                AND FD.Fstatus = ''ENABLED''
                                AND EXISTS ( SELECT 1 FROM V_T_ADVICE_FEE V WHERE FD.FORDER_ID = V.FORDER_ID)
                   ) T GROUP BY  FORDER_ID , FMANAGER_ORG_ID , FMANAGER_ID , IS_OUT_BUSS,FFUND_TYPE
            ),
            /**逾期费*/
            V_T_OVERDUE_FEE AS (
                    SELECT ''OVERDUE'' AS DATA_TYPE ,V_ORDER.FORDER_ID, V_ORDER.FORG_ID AS FMANAGER_ORG_ID , V_ORDER.PARTNER_ID AS FMANAGER_ID ,V_ORDER.IS_OUT_BUSS_NEW AS IS_OUT_BUSS ,V_ORDER.FFUND_TYPE,
                           SUM(FFEE_MONEY) AS OVERDUE_FEE
                    FROM T_FN_FIN_FEE_DETAILS FD
                         LEFT JOIN V_ORDER_REPAYMENT_REDEEM V_ORDER   ON V_ORDER.FORDER_ID = FD.FORDER_ID
                    WHERE FD.FFEE_TYPE = ''OVERDUE_FEE''
                     AND TO_CHAR(FD.FCHARGE_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                     AND TO_CHAR(FD.FCHARGE_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                     AND EXISTS ( SELECT 1 FROM V_T_ADVICE_FEE V WHERE FD.FORDER_ID = V.FORDER_ID)
                     GROUP BY V_ORDER.FORDER_ID , V_ORDER.FORG_ID , V_ORDER.PARTNER_ID , V_ORDER.IS_OUT_BUSS_NEW,V_ORDER.FFUND_TYPE
            ),
            /**往期逾期费*/
            V_T_OVERDUE_LAST_FEE AS (
                    SELECT ''OVERDUE'' AS DATA_TYPE ,V_ORDER.FORDER_ID, V_ORDER.FORG_ID AS FMANAGER_ORG_ID , V_ORDER.PARTNER_ID AS FMANAGER_ID ,V_ORDER.IS_OUT_BUSS_NEW AS IS_OUT_BUSS ,V_ORDER.FFUND_TYPE,
                           SUM(FFEE_MONEY) AS OVERDUE_LAST_FEE
                    FROM T_FN_FIN_FEE_DETAILS FD
                         LEFT JOIN V_ORDER_REPAYMENT_REDEEM V_ORDER   ON V_ORDER.FORDER_ID = FD.FORDER_ID
                    WHERE FD.FFEE_TYPE = ''OVERDUE_FEE''
                     AND TO_CHAR(FD.FCHARGE_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                     AND TO_CHAR(FD.FCHARGE_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                     AND EXISTS ( SELECT 1 FROM V_T_ORDER_LAST V WHERE FD.FORDER_ID = V.FORDER_ID)
                     GROUP BY V_ORDER.FORDER_ID , V_ORDER.FORG_ID , V_ORDER.PARTNER_ID , V_ORDER.IS_OUT_BUSS_NEW ,V_ORDER.FFUND_TYPE
            ),
            /**退费*/
            V_T_REFUND_FEE AS (
                    SELECT ''REFUND'' AS DATA_TYPE ,FORDER_ID,FMANAGER_ORG_ID,FMANAGER_ID,IS_OUT_BUSS,FFUND_TYPE,
                           SUM(FREFUND_MONEY) AS FREFUND_MONEY
                    FROM(
                           SELECT OB.FORDER_ID,OB.FMANAGER_ORG_ID , OB.FMANAGER_ID ,
                             CASE WHEN G.FGUARANTEE_TYPE = ''INTERNAL'' THEN 0 ELSE 1 END  AS  IS_OUT_BUSS,
                             BT.FFUND_TYPE,
                             FAPPROVAL_MONEY AS FREFUND_MONEY
                          FROM T_FN_FIN_REFUND_FEE_DETAILS REFUND
                               LEFT JOIN T_RISK_REVOKE_ORDER RO ON RO.FORDER_ID = REFUND.FORDER_ID
                               LEFT JOIN T_SURETY_ORDER_BASE OB   ON OB.FORDER_ID = REFUND.FORDER_ID
                               LEFT JOIN T_SURETY_GUARANTEE G ON G.FID = OB.FORDER_ID
                               LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON BT.FID = OB.FBIZ_ID
                               LEFT JOIN V_ORDER_REVOKE_CAN_REFUND RCR ON RCR.FORDER_ID = OB.FORDER_ID
                          WHERE
                                (REFUND.FHANDLE_STATUS = ''FINISH_HANDLE'' OR  RCR.CAN_REFUND_MONEY = 0 )
                                AND TO_CHAR(REFUND.FREFUND_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                                AND TO_CHAR(REFUND.FREFUND_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                                AND ( EXISTS( SELECT 1 FROM V_T_ADVICE_FEE V WHERE REFUND.FORDER_ID = V.FORDER_ID) OR EXISTS (SELECT 1  FROM V_T_REVOKE_FEE V WHERE REFUND.FORDER_ID = V.FORDER_ID))
                                AND REFUND.FORDER_ID NOT IN ( SELECT FORDER_ID FROM T_RISK_REVOKE_ORDER  WHERE FIS_CHARGE = ''NO'' AND FSTATUS = ''ENABLED'' )
                   ) T GROUP BY  FORDER_ID , FMANAGER_ORG_ID , FMANAGER_ID , IS_OUT_BUSS,FFUND_TYPE
            ),
            /**往期退费*/
            V_T_REFUND_LAST_FEE AS (
                    SELECT ''REFUND'' AS DATA_TYPE ,FORDER_ID,FMANAGER_ORG_ID,FMANAGER_ID,IS_OUT_BUSS,FFUND_TYPE,
                           SUM(FREFUND_MONEY) AS FREFUND_LAST_MONEY
                    FROM(
                           SELECT OB.FORDER_ID,OB.FMANAGER_ORG_ID , OB.FMANAGER_ID ,
                             CASE WHEN G.FGUARANTEE_TYPE = ''INTERNAL'' THEN 0 ELSE 1 END  AS  IS_OUT_BUSS,
                             BT.FFUND_TYPE,
                             FAPPROVAL_MONEY AS FREFUND_MONEY
                          FROM T_FN_FIN_REFUND_FEE_DETAILS REFUND
                               LEFT JOIN T_RISK_REVOKE_ORDER RO ON RO.FORDER_ID = REFUND.FORDER_ID
                               LEFT JOIN T_SURETY_ORDER_BASE OB   ON OB.FORDER_ID = REFUND.FORDER_ID
                               LEFT JOIN T_SURETY_GUARANTEE G ON G.FID = OB.FORDER_ID
                               LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON BT.FID = OB.FBIZ_ID
                               LEFT JOIN V_ORDER_REVOKE_CAN_REFUND RCR ON RCR.FORDER_ID = OB.FORDER_ID
                          WHERE (REFUND.FHANDLE_STATUS = ''FINISH_HANDLE'' OR  RCR.CAN_REFUND_MONEY = 0 )
                                AND TO_CHAR(REFUND.FREFUND_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||'''
                                AND TO_CHAR(REFUND.FREFUND_DATE,''YYYY-MM-DD'') <= ''' || IN_QUERY_END_DATE ||'''
                                AND  ( EXISTS( SELECT FORDER_ID FROM V_T_ORDER_LAST V WHERE REFUND.FORDER_ID = V.FORDER_ID) OR EXISTS (SELECT FORDER_ID FROM V_T_ORDER_REFUND_LAST V WHERE REFUND.FORDER_ID = V.FORDER_ID))
                                AND REFUND.FORDER_ID NOT IN ( SELECT FORDER_ID FROM T_RISK_REVOKE_ORDER  WHERE FIS_CHARGE = ''NO'' AND FSTATUS = ''ENABLED'' )
                   ) T GROUP BY  FORDER_ID , FMANAGER_ORG_ID , FMANAGER_ID , IS_OUT_BUSS,FFUND_TYPE
            ),
            /**订单基础*/
            V_T_ORDER_BASE AS (
                   SELECT DATA_TYPE, 1 AS IS_COUNT , FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY FROM  V_T_ADVICE_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 1 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY FROM  V_T_REVOKE_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY  FROM  V_T_REBATE_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , 0 AS REBATE , DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY  FROM  V_T_DELAY_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY  FROM  V_T_OVERDUE_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY  FROM  V_T_OVERDUE_LAST_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , FREFUND_MONEY ,0 AS FREFUND_LAST_MONEY  FROM  V_T_REFUND_FEE
                   UNION ALL
                   SELECT DATA_TYPE, 0 AS IS_COUNT ,FORDER_ID,FMANAGER_ORG_ID , FMANAGER_ID, IS_OUT_BUSS, FFUND_TYPE,
                          0 AS ADVICE_TOTAL_FEE , 0 AS REBATE , 0 AS DELAY_FEE , 0 AS DELAY_LAST_FEE , 0 AS OVERDUE_FEE , 0 AS OVERDUE_LAST_FEE , 0 AS FREFUND_MONEY ,FREFUND_LAST_MONEY  FROM  V_T_REFUND_LAST_FEE
            ),
            /**订单基础汇总*/
            V_T_ORDER_BASE_SUM AS (
                   SELECT V_OB.FORDER_ID , IS_COUNT , V_OB.FMANAGER_ORG_ID , V_OB.FMANAGER_ID, V_OB.IS_OUT_BUSS,V_OB.FFUND_TYPE, OB.FMANAGER_LEVEL,
                          SUM(ADVICE_TOTAL_FEE) AS ADVICE_TOTAL_FEE,
                          SUM(REBATE) AS REBATE,
                          SUM(DELAY_FEE) AS DELAY_FEE,
                          SUM(DELAY_LAST_FEE) AS DELAY_LAST_FEE,
                          SUM(OVERDUE_FEE) AS OVERDUE_FEE,
                          SUM(OVERDUE_LAST_FEE) AS OVERDUE_LAST_FEE,
                          SUM(FREFUND_MONEY) AS FREFUND_MONEY,
                          SUM(FREFUND_LAST_MONEY) AS FREFUND_LAST_MONEY
                   FROM V_T_ORDER_BASE V_OB
                        LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = V_OB.FORDER_ID
                   GROUP BY V_OB.FORDER_ID , IS_COUNT , V_OB.FMANAGER_ORG_ID , V_OB.FMANAGER_ID, V_OB.IS_OUT_BUSS,V_OB.FFUND_TYPE, OB.FMANAGER_LEVEL
            ),
            /**订单人员汇总*/
            V_T_ORDER_PERSON_SUM AS (
                   SELECT FMANAGER_ORG_ID , FMANAGER_ID,FMANAGER_LEVEL,IS_OUT_BUSS,
                          /**额度+现金合计*/
                          SUM(CASE WHEN IS_OUT_BUSS = 0 THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS TOTAL_IN_MONEY,
                          SUM(CASE WHEN IS_OUT_BUSS = 1 THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS TOTAL_OUT_MONEY,
                          SUM(ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY) AS TOTAL_IN_OUT_MONEY,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 0 THEN 1 ELSE 0 END ) AS TOTAL_IN_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 1 THEN 1 ELSE 0 END ) AS TOTAL_OUT_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND ADVICE_TOTAL_FEE != 0 THEN 1 ELSE 0 END ) AS TOTAL_IN_OUT_COUNT,
                          /**额度*/
                          SUM(CASE WHEN IS_OUT_BUSS = 0 AND FFUND_TYPE = ''AMOUNT'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS AMOUNT_IN_MONEY,
                          SUM(CASE WHEN IS_OUT_BUSS = 1 AND FFUND_TYPE = ''AMOUNT'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS AMOUNT_OUT_MONEY,
                          SUM(CASE WHEN FFUND_TYPE = ''AMOUNT'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS AMOUNT_TOTAL_IN_OUT_MONEY,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 0 AND FFUND_TYPE = ''AMOUNT'' THEN 1 ELSE 0 END ) AS AMOUNT_IN_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 1 AND FFUND_TYPE = ''AMOUNT'' THEN 1 ELSE 0 END ) AS AMOUNT_OUT_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND FFUND_TYPE = ''AMOUNT'' AND ADVICE_TOTAL_FEE != 0 THEN 1 ELSE 0 END ) AS AMOUNT_TOTAL_IN_OUT_COUNT,
                          /**现金*/
                          SUM(CASE WHEN IS_OUT_BUSS = 0 AND FFUND_TYPE = ''CASH'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS CASH_IN_MONEY,
                          SUM(CASE WHEN IS_OUT_BUSS = 1 AND FFUND_TYPE = ''CASH'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS CASH_OUT_MONEY,
                          /**现金-往期*/
                          SUM(CASE WHEN IS_OUT_BUSS = 0 AND FFUND_TYPE = ''CASH'' THEN DELAY_LAST_FEE + OVERDUE_LAST_FEE + FREFUND_LAST_MONEY ELSE 0 END ) AS CASH_REFUND_IN_MONEY,
                          SUM(CASE WHEN IS_OUT_BUSS = 1 AND FFUND_TYPE = ''CASH'' THEN DELAY_LAST_FEE + OVERDUE_LAST_FEE + FREFUND_LAST_MONEY ELSE 0 END ) AS CASH_REFUND_OUT_MONEY,
                          SUM(CASE WHEN FFUND_TYPE = ''CASH'' THEN ADVICE_TOTAL_FEE + DELAY_FEE + DELAY_LAST_FEE + OVERDUE_FEE +  OVERDUE_LAST_FEE - REBATE - FREFUND_MONEY ELSE 0 END ) AS CASH_TOTAL_IN_OUT_MONEY,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 0 AND FFUND_TYPE = ''CASH'' THEN 1 ELSE 0 END) AS CASH_IN_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND IS_OUT_BUSS = 1 AND FFUND_TYPE = ''CASH'' THEN 1 ELSE 0 END) AS CASH_OUT_COUNT,
                          SUM(CASE WHEN IS_COUNT = 1 AND FFUND_TYPE = ''CASH'' THEN 1 ELSE 0 END) AS CASH_TOTAL_IN_OUT_COUNT
                   FROM V_T_ORDER_BASE_SUM
                   GROUP BY FMANAGER_ORG_ID , FMANAGER_ID,FMANAGER_LEVEL,IS_OUT_BUSS
            ),
            /**订单人员汇总-合计*/
            V_T_ORDER_PERSON_CALC_SUM AS (
                           SELECT FMANAGER_ORG_ID , FMANAGER_ID,
                                  /**总业绩*/
                                  SUM(TOTAL_IN_OUT_MONEY ) AS TOTAL_MONEY,
                                  /**额度+现金合计*/
                                  SUM(TOTAL_IN_MONEY) AS TOTAL_IN_MONEY,
                                  SUM(TOTAL_OUT_MONEY ) AS TOTAL_OUT_MONEY,
                                  SUM(TOTAL_IN_OUT_MONEY) AS TOTAL_IN_OUT_MONEY,
                                  SUM(TOTAL_IN_COUNT) AS TOTAL_IN_COUNT,
                                  SUM(TOTAL_OUT_COUNT) AS TOTAL_OUT_COUNT,
                                  SUM(TOTAL_IN_OUT_COUNT) AS TOTAL_IN_OUT_COUNT,
                                  /**额度*/
                                  SUM(AMOUNT_IN_MONEY ) AS AMOUNT_IN_MONEY,
                                  SUM(AMOUNT_OUT_MONEY) AS AMOUNT_OUT_MONEY,
                                  SUM(AMOUNT_TOTAL_IN_OUT_MONEY ) AS AMOUNT_TOTAL_IN_OUT_MONEY,
                                  SUM(AMOUNT_IN_COUNT) AS AMOUNT_IN_COUNT,
                                  SUM(AMOUNT_OUT_COUNT) AS AMOUNT_OUT_COUNT,
                                  SUM(AMOUNT_TOTAL_IN_OUT_COUNT) AS AMOUNT_TOTAL_IN_OUT_COUNT,
                                  /**现金*/
                                  SUM(CASH_IN_MONEY) AS CASH_IN_MONEY,
                                  SUM(CASH_OUT_MONEY) AS CASH_OUT_MONEY,
                                  /**现金-往期*/
                                  SUM(CASH_REFUND_IN_MONEY) AS CASH_REFUND_IN_MONEY,
                                  SUM(CASH_REFUND_OUT_MONEY) AS CASH_REFUND_OUT_MONEY,
                                  SUM(CASH_IN_MONEY + CASH_REFUND_IN_MONEY) AS CASH_IN_SUM_MONEY,
                                  SUM(CASH_OUT_MONEY + CASH_REFUND_OUT_MONEY) AS CASH_OUT_SUM_MONEY,
                                  SUM(CASH_TOTAL_IN_OUT_MONEY) AS CASH_TOTAL_IN_OUT_MONEY,
                                  SUM(CASH_IN_COUNT) AS CASH_IN_COUNT,
                                  SUM(CASH_OUT_COUNT) AS CASH_OUT_COUNT,
                                  SUM(CASH_TOTAL_IN_OUT_COUNT) AS CASH_TOTAL_IN_OUT_COUNT,
                                  /**计薪人员-外单业绩*/
                                  SUM(CASE WHEN FMANAGER_LEVEL !=''INTERNSHIP'' AND IS_OUT_BUSS = 1 THEN  TOTAL_OUT_MONEY ELSE 0 END) AS CALC_OUT_MONEY,
                                  /**计薪人员-总业绩*/
                                  SUM(CASE WHEN FMANAGER_LEVEL !=''INTERNSHIP'' THEN  TOTAL_IN_OUT_MONEY ELSE 0 END) AS CALC_TOTAL_MONEY
                           FROM V_T_ORDER_PERSON_SUM
                           GROUP BY FMANAGER_ORG_ID , FMANAGER_ID
             ),
             /**汇总组织人员+权限*/
             V_T_ORDER_PERSON_CALC_SUM_AUTH AS(
                    SELECT distinct ''PERSON'' AS DATA_TYPE,
                          ORG.FID AS ORG_ID, ORG.FPARENT_ID AS ORG_PARENT_ID , ORG.FNAME AS ORG_NAME, ORG.FLONG_NUMBER , ORG.FLEVEL AS ORG_LEVEL,
                          P.FID AS PERSON_ID, P.FNAME AS  PERSON_NAME, P.FJOIN_DATE, P.FLEAVE_DATE, P.FLEVEL as PERSON_LEVEL,
                          /**总业绩*/
                          V_P_S.TOTAL_MONEY,
                          /**额度+现金合计*/
                          V_P_S.TOTAL_IN_MONEY,
                          V_P_S.TOTAL_OUT_MONEY,
                          V_P_S.TOTAL_IN_OUT_MONEY,
                          V_P_S.TOTAL_IN_COUNT,
                          V_P_S.TOTAL_OUT_COUNT,
                          V_P_S.TOTAL_IN_OUT_COUNT,
                          /**额度*/
                          V_P_S.AMOUNT_IN_MONEY,
                          V_P_S.AMOUNT_OUT_MONEY,
                          V_P_S.AMOUNT_TOTAL_IN_OUT_MONEY,
                          V_P_S.AMOUNT_IN_COUNT,
                          V_P_S.AMOUNT_OUT_COUNT,
                          V_P_S.AMOUNT_TOTAL_IN_OUT_COUNT,
                          /**现金*/
                          V_P_S.CASH_IN_MONEY,
                          V_P_S.CASH_OUT_MONEY,
                          /**现金-往期*/
                          V_P_S.CASH_REFUND_IN_MONEY,
                          V_P_S.CASH_REFUND_OUT_MONEY,
                          V_P_S.CASH_IN_SUM_MONEY,
                          V_P_S.CASH_OUT_SUM_MONEY,
                          V_P_S.CASH_TOTAL_IN_OUT_MONEY,
                          V_P_S.CASH_IN_COUNT,
                          V_P_S.CASH_OUT_COUNT,
                          V_P_S.CASH_TOTAL_IN_OUT_COUNT,
                          /**计薪人员*/
                          V_P_S.CALC_OUT_MONEY,
                          V_P_S.CALC_TOTAL_MONEY,
                          CASE WHEN (P.FLEVEL =''INTERNSHIP'' ) THEN  0 ELSE 1 END AS CALC_TOTAL_COUNT,
                          1 AS TOTAL_PERSON_COUNT
                  FROM T_ERP_ORG ORG
                        LEFT JOIN V_ERP_ORG_ALL_PERSON P ON P.FORG_ID = ORG.FID
                        LEFT JOIN V_T_ORDER_PERSON_CALC_SUM V_P_S ON V_P_S.FMANAGER_ID = P.FID
                        INNER JOIN  V_T_AUTH A ON INSTR(ORG.FLONG_NUMBER, A.LONG_NUMBER)> 0
                  WHERE ORG.FORG_TYPE != ''MANAGE''
                      AND ORG.FSTATUS = ''ENABLED''
                        AND ( TO_CHAR(P.FLEAVE_DATE,''YYYY-MM-DD'') >= ''' || IN_QUERY_BEGIN_DATE ||''' OR  P.FLEAVE_DATE IS NULL)
                        /*查询机构条件*/
                        ' || V_WHERE_AUTH_SQL || '
             ) ,
             /**汇总组织-往上汇总*/
             V_T_ORDER_ORG_SUM AS (
                 SELECT distinct T.ORG_ID, T.ORG_PARENT_ID , T.ORG_NAME, T.FLONG_NUMBER , T.ORG_LEVEL,
                                  /**总业绩*/
                                  ( SELECT SUM(TOTAL_IN_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_MONEY,
                                  /**额度+现金合计*/
                                  ( SELECT SUM(TOTAL_IN_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_IN_MONEY,
                                  ( SELECT SUM(TOTAL_OUT_MONEY )  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_OUT_MONEY,
                                  ( SELECT SUM(TOTAL_IN_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_IN_OUT_MONEY,
                                  ( SELECT SUM(TOTAL_IN_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_IN_COUNT,
                                  ( SELECT SUM(TOTAL_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_OUT_COUNT,
                                  ( SELECT SUM(TOTAL_IN_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS TOTAL_IN_OUT_COUNT,
                                  /**额度*/
                                  ( SELECT SUM(AMOUNT_IN_MONEY )  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_IN_MONEY,
                                  ( SELECT SUM(AMOUNT_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_OUT_MONEY,
                                  ( SELECT SUM(AMOUNT_TOTAL_IN_OUT_MONEY )  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_TOTAL_IN_OUT_MONEY,
                                  ( SELECT SUM(AMOUNT_IN_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_IN_COUNT,
                                  ( SELECT SUM(AMOUNT_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_OUT_COUNT,
                                  ( SELECT SUM(AMOUNT_TOTAL_IN_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS AMOUNT_TOTAL_IN_OUT_COUNT,
                                  /**现金*/
                                  ( SELECT SUM(CASH_IN_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_IN_MONEY,
                                  ( SELECT SUM(CASH_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_OUT_MONEY,
                                  /**现金-往期*/
                                  ( SELECT SUM(CASH_REFUND_IN_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_REFUND_IN_MONEY,
                                  ( SELECT SUM(CASH_REFUND_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_REFUND_OUT_MONEY,
                                  ( SELECT SUM(CASH_IN_MONEY + CASH_REFUND_IN_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_IN_SUM_MONEY,
                                  ( SELECT SUM(CASH_OUT_MONEY + CASH_REFUND_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_OUT_SUM_MONEY,
                                  ( SELECT SUM(CASH_TOTAL_IN_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_TOTAL_IN_OUT_MONEY,
                                  ( SELECT SUM(CASH_IN_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_IN_COUNT,
                                  ( SELECT SUM(CASH_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_OUT_COUNT,
                                  ( SELECT SUM(CASH_TOTAL_IN_OUT_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'')  AS CASH_TOTAL_IN_OUT_COUNT,
                                  /**计薪*/
                                  ( SELECT SUM(CALC_OUT_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%''  )  AS CALC_OUT_MONEY,
                                  ( SELECT SUM(CALC_TOTAL_MONEY)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'' )  AS CALC_TOTAL_MONEY,
                                  ( SELECT SUM(CALC_TOTAL_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'' )  AS CALC_TOTAL_COUNT,
                                  ( SELECT SUM(TOTAL_PERSON_COUNT)  FROM  V_T_ORDER_PERSON_CALC_SUM_AUTH  WHERE FLONG_NUMBER LIKE T.FLONG_NUMBER || ''%'' )  AS TOTAL_PERSON_COUNT
                        FROM V_T_ORDER_PERSON_CALC_SUM_AUTH T
             ),
   ';

   V_WITH_DATA_SQL := '
             /**汇总组织+负责人*/
             V_T_ORDER_ORG_SUM_MANAGER AS (
                 SELECT distinct ''ORG'' AS DATA_TYPE,  T.ORG_ID, T.ORG_PARENT_ID , T.ORG_NAME, T.FLONG_NUMBER , T.ORG_LEVEL,
                                  P.PERSON_ID , P.PERSON_NAME , P.FJOIN_DATE , P.FLEAVE_DATE , P.PERSON_LEVEL ,
                                  /**总业绩*/
                                  T.TOTAL_MONEY,
                                  /**额度+现金合计*/
                                  T.TOTAL_IN_MONEY,
                                  T.TOTAL_OUT_MONEY,
                                  T.TOTAL_IN_OUT_MONEY,
                                  T.TOTAL_IN_COUNT,
                                  T.TOTAL_OUT_COUNT,
                                  T.TOTAL_IN_OUT_COUNT,
                                  /**额度*/
                                  T.AMOUNT_IN_MONEY,
                                  T.AMOUNT_OUT_MONEY,
                                  T.AMOUNT_TOTAL_IN_OUT_MONEY,
                                  T.AMOUNT_IN_COUNT,
                                  T.AMOUNT_OUT_COUNT,
                                  T.AMOUNT_TOTAL_IN_OUT_COUNT,
                                  /**现金*/
                                  T.CASH_IN_MONEY,
                                  T.CASH_OUT_MONEY,
                                  /**现金-往期*/
                                  T.CASH_REFUND_IN_MONEY,
                                  T.CASH_REFUND_OUT_MONEY,
                                  T.CASH_IN_SUM_MONEY,
                                  T.CASH_OUT_SUM_MONEY,
                                  T.CASH_TOTAL_IN_OUT_MONEY,
                                  T.CASH_IN_COUNT,
                                  T.CASH_OUT_COUNT,
                                  T.CASH_TOTAL_IN_OUT_COUNT,
                                  /**计薪*/
                                  T.CALC_OUT_MONEY,
                                  T.CALC_TOTAL_MONEY,
                                  /**人数*/
                                  T.CALC_TOTAL_COUNT,
                                  T.TOTAL_PERSON_COUNT
                        FROM V_T_ORDER_ORG_SUM T
                             LEFT JOIN V_ERP_ORG_MANAGER_ONE_PERSON P ON P.ORG_ID = T.ORG_ID
             ),
             /**汇总组织+负责人+人均*/
             V_T_ORDER_ORG_SUM_AVG_MANAGER AS (
                 SELECT distinct DATA_TYPE,  T.ORG_ID, T.ORG_PARENT_ID , T.ORG_NAME, T.FLONG_NUMBER , T.ORG_LEVEL,
                                  P.PERSON_ID , P.PERSON_NAME , TO_CHAR(P.FJOIN_DATE,''YYYY-MM-DD'') AS FJOIN_DATE, TO_CHAR(P.FLEAVE_DATE,''YYYY-MM-DD'') AS FLEAVE_DATE , P.PERSON_LEVEL ,
                                  /**总业绩*/
                                  T.TOTAL_MONEY,
                                  /**额度+现金合计*/
                                  T.TOTAL_IN_MONEY,
                                  T.TOTAL_OUT_MONEY,
                                  T.TOTAL_IN_OUT_MONEY,
                                  T.TOTAL_IN_COUNT,
                                  T.TOTAL_OUT_COUNT,
                                  T.TOTAL_IN_OUT_COUNT,
                                  /**额度*/
                                  T.AMOUNT_IN_MONEY,
                                  T.AMOUNT_OUT_MONEY,
                                  T.AMOUNT_TOTAL_IN_OUT_MONEY,
                                  T.AMOUNT_IN_COUNT,
                                  T.AMOUNT_OUT_COUNT,
                                  T.AMOUNT_TOTAL_IN_OUT_COUNT,
                                  /**现金*/
                                  T.CASH_IN_MONEY,
                                  T.CASH_OUT_MONEY,
                                  /**现金-往期*/
                                  T.CASH_REFUND_IN_MONEY,
                                  T.CASH_REFUND_OUT_MONEY,
                                  T.CASH_IN_SUM_MONEY,
                                  T.CASH_OUT_SUM_MONEY,
                                  T.CASH_TOTAL_IN_OUT_MONEY,
                                  T.CASH_IN_COUNT,
                                  T.CASH_OUT_COUNT,
                                  T.CASH_TOTAL_IN_OUT_COUNT,
                                  /**计薪*/
                                  T.CALC_OUT_MONEY,
                                  T.CALC_TOTAL_MONEY,
                                  T.CALC_TOTAL_COUNT,
                                  /**人均*/
                                  CASE WHEN T.TOTAL_PERSON_COUNT > 0 THEN ROUND(T.TOTAL_MONEY/T.CALC_TOTAL_COUNT,2) ELSE 0 END AS CALC_AVG_MONEY
                             FROM V_T_ORDER_ORG_SUM_MANAGER T
                             LEFT JOIN V_ERP_ORG_MANAGER_ONE_PERSON P ON P.ORG_ID = T.ORG_ID
                             WHERE 1 = 1  '|| V_WHERE_PERSON_SQL ||'
             ),
             /**汇总组织+业务人员*/
             V_T_ORDER_PERSON_SUM_BUSS AS(
                    SELECT DATA_TYPE,
                          ORG_ID,  ORG_PARENT_ID , ORG_NAME, FLONG_NUMBER ,  ORG_LEVEL,
                          PERSON_ID, PERSON_NAME, TO_CHAR(FJOIN_DATE,''YYYY-MM-DD'') AS FJOIN_DATE, TO_CHAR(FLEAVE_DATE,''YYYY-MM-DD'') AS FLEAVE_DATE, PERSON_LEVEL,
                          /**总业绩*/
                          TOTAL_MONEY,
                          /**额度+现金合计*/
                          TOTAL_IN_MONEY,
                          TOTAL_OUT_MONEY,
                          TOTAL_IN_OUT_MONEY,
                          TOTAL_IN_COUNT,
                          TOTAL_OUT_COUNT,
                          TOTAL_IN_OUT_COUNT,
                          /**额度*/
                          AMOUNT_IN_MONEY,
                          AMOUNT_OUT_MONEY,
                          AMOUNT_TOTAL_IN_OUT_MONEY,
                          AMOUNT_IN_COUNT,
                          AMOUNT_OUT_COUNT,
                          AMOUNT_TOTAL_IN_OUT_COUNT,
                          /**现金*/
                          CASH_IN_MONEY,
                          CASH_OUT_MONEY,
                          /**现金-往期*/
                          CASH_REFUND_IN_MONEY,
                          CASH_REFUND_OUT_MONEY,
                          CASH_IN_SUM_MONEY,
                          CASH_OUT_SUM_MONEY,
                          CASH_TOTAL_IN_OUT_MONEY,
                          CASH_IN_COUNT,
                          CASH_OUT_COUNT,
                          CASH_TOTAL_IN_OUT_COUNT,
                          /**计薪人员*/
                          CALC_OUT_MONEY,
                          CALC_TOTAL_MONEY,
                          CALC_TOTAL_COUNT,
                          NULL AS CALC_AVG_MONEY
                  FROM V_T_ORDER_PERSON_CALC_SUM_AUTH T
                       WHERE  T.PERSON_ID IS NOT NULL
                             '|| V_WHERE_PERSON_SQL ||'
             ),
             /**合并数据*/
             V_T_ALL AS(
                     SELECT * FROM V_T_ORDER_PERSON_SUM_BUSS
                       UNION ALL
                      SELECT * FROM V_T_ORDER_ORG_SUM_AVG_MANAGER
             )
     ';




   /*行结果集SQL*/
   V_ROW_RESULT_SQL :='SELECT * FROM V_T_ALL T ORDER BY T.ORG_ID ASC , T.DATA_TYPE ASC ,  T.ORG_LEVEL ASC , T.FLONG_NUMBER ASC , T.FJOIN_DATE ASC , T.PERSON_ID ASC  ';

   /*执行总SQL*/
   V_SQL := V_WITH_SQL ||  ' ' ||  V_WITH_DATA_SQL ||  ' ' ||  V_ROW_RESULT_SQL;

   DBMS_OUTPUT.PUT_LINE('/*执行总SQL:>>>>>>>==================*/');
   DBMS_OUTPUT.PUT_LINE( V_WITH_SQL);
   DBMS_OUTPUT.PUT_LINE( V_WITH_DATA_SQL);
   DBMS_OUTPUT.PUT_LINE( V_ROW_RESULT_SQL);


   /*执行*/
   OPEN OUT_DATASET FOR V_SQL;
EXCEPTION
      /*异常捕捉，不要把有需要的代码放在异常捕捉后面，有异常才会执行异常代码下所有代码，没有异常不会执行*/
      WHEN GLOBAL_ERROR_EXCEPTION THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
      WHEN OTHERS THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
           DBMS_OUTPUT.PUT_LINE(GLOBAL_OUT_RETURN);
END PRO_REPORT_ORG_PERSON_PERF ;
END PKG_REPORT_ORG_PERSON_PERF;
/
