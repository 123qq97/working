CREATE PACKAGE PKG_REPORT_ORG_PERSON_PERF
AS
    TYPE GET_CURSOR IS  REF CURSOR;
    PROCEDURE PRO_REPORT_ORG_PERSON_PERF
    (
       IN_QUERY_BEGIN_DATE IN VARCHAR,      /*输入-开始日期YYYY-mm-dd*/
       IN_QUERY_END_DATE IN VARCHAR,        /*输入-结束日期YYYY-mm-dd*/
       IN_QUERY_ORG_ID IN VARCHAR,          /*输入-组织ID*/
       IN_QUERY_PERSON_ID IN VARCHAR,       /*输入-客户经理ID*/
       IN_LONG_NUMBERS IN VARCHAR,          /*输入-长编码，多个用逗号隔开*/
       OUT_DATASET OUT GET_CURSOR           /*输出-结果集*/
    );
END PKG_REPORT_ORG_PERSON_PERF;
/
