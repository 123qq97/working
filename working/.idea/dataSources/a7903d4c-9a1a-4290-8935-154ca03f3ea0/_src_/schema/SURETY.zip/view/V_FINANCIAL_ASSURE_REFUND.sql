CREATE VIEW V_FINANCIAL_ASSURE_REFUND AS (
SELECT   FD.FID                                         FID,
         CCITY.FID                                      SOURCEHEADERID,
         FD.FID                                         sourceLineId,
         to_char(FD.FHANDLE_TIME,'yyyy-mm-dd')          refundDate,
         FD.FPAY_ACCOUNT_NUMBER                         bankNum,
     CCITY.FCOMPANY_CODE                            orgName,
         CCITY.FCOMPANY_CODE                            deptCode,
         CCITY.FSUB_COMPANY_NAME                        deptName,
     'CITY'                                         orgType,
         CCITY.FCOMPANY_CODE                            teamId,
         CCITY.FSUB_COMPANY_NAME                        teamName,
         CCITY.FCITY_CODE                               cityCode,
         CCITY.FCOMPANY_CODE                            cusOrgCode,
         CCITY.FSUB_COMPANY_NAME                        cusOrgName,
         decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                          ownFlag,
         FD.FID                                         refundNum,
         'DEPOSIT-C'                                    refundTypeCode,
         ''||FD.FCONFIRM_REFUND_MONEY                   refundAmount,
         'CNY'                                          currencyCode,
         'BANK'                                         refundMethodCode
         FROM T_FN_FIN_REFUND_ORG_ASSURE FD
         LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON FD.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
         LEFT JOIN T_FN_ASSETS_INFO AI ON CCITY.FFN_ASSETS_INFO = AI.FID

)
/
