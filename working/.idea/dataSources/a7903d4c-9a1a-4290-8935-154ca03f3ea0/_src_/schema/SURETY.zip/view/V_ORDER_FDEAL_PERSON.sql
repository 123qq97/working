CREATE VIEW V_ORDER_FDEAL_PERSON AS SELECT guarantee.fid as FORDER_ID,
       SELL.FSELLER,
       BUY.FBUYER,
       EST.FEST_NAME,
       EST.FEST_NAME2
  FROM T_surety_guarantee guarantee
  left join (SELECT FGUARANTEE_ID AS FORDER_ID,
                    TO_STRING(CAST(COLLECT(TO_CHAR(FCLT_NAME)) AS
                                   VARCHAR2_TABLE)) AS FSELLER
               FROM T_SURETY_G_PERSON_INFO_TRADES
              WHERE FCLT_TYP = 'SELLER'
              GROUP BY FGUARANTEE_ID) SELL
    on guarantee.fid = SELL.FORDER_ID
  LEFT JOIN (SELECT FGUARANTEE_ID AS FORDER_ID,
                    TO_STRING(CAST(COLLECT(TO_CHAR(FCLT_NAME)) AS
                                   VARCHAR2_TABLE)) AS FBUYER
               FROM T_SURETY_G_PERSON_INFO_TRADES
              WHERE FCLT_TYP = 'BUYER'
              GROUP BY FGUARANTEE_ID) BUY
    ON BUY.FORDER_ID = guarantee.fid
  LEFT JOIN (SELECT FGUARANTEE_ID AS FORDER_ID,
                    TO_STRING(CAST(COLLECT(TO_CHAR(FESTATE_NAME)) AS
                                   VARCHAR2_TABLE)) AS FEST_NAME,
                    TO_STRING(CAST(COLLECT(TO_CHAR(FESTATE_NAME ||
                                                   '   房产证号: ' || FDEED_NUM)) AS
                                   VARCHAR2_TABLE)) AS FEST_NAME2
               FROM T_SURETY_G_ESTATE_SELLER
              GROUP BY FGUARANTEE_ID) EST
    ON EST.FORDER_ID = guarantee.fid
/
