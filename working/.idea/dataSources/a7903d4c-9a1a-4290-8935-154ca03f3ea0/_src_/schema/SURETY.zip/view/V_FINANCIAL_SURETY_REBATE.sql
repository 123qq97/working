CREATE VIEW V_FINANCIAL_SURETY_REBATE AS (
SELECT SR.FID                                                      FID,
       GUA.FID                                                     sourceHeaderId,
       SR.FID                                                      sourceLineId,
       to_char(SR.FPAYMENT_TIME,'yyyy-mm-dd')                      commissionDate,
       ORG.FID                                                     orgId,
       SR.FBILLING_ACCOUNT_NUMBER                                  bankNum,
       ORG.FNUMBER                                                 deptCode,
       ORG.FNAME                                                   deptName,
     ORG.FORG_TYPE                                               orgType,
       PORG.Fnumber                                                teamId,
       PORG.FNAME                                                  teamName,
       '待定'                                                      channelCode,
       '待定'                                                      channelName,
       GUA.FGUARANTEE_NUM                                          documentNum,
       'COMMISION'                                                 refundNum,
       'CNY'                                                       currencyCode,
       ''||SR.REBATE                                               commissionAmount,
       'BANK'                                                      paymentMethod
from T_SURETY_REBATE SR
LEFT JOIN T_SURETY_GUARANTEE GUA ON SR.FGUARANTEE_ID = GUA.FID
LEFT JOIN T_ERP_PERSON PE ON GUA.FCREATE_OPERATOR_ID = PE.FID
LEFT JOIN T_ERP_ORG ORG ON PE.FORG_ID = ORG.FID
LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
)
/
