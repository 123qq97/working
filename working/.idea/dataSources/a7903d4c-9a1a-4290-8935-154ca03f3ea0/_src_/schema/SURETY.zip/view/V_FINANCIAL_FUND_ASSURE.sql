CREATE VIEW V_FINANCIAL_FUND_ASSURE AS (
SELECT    FA.FID                                           fid,
          FI.FID                                           sourceHeaderId,
          FA.FID                                           sourceLineId,
          FA.FID                                           receiptNum,
          OC.FCODE                                         orgName,
          '330200'                                         cityCode,
          FI.FFUND_CODE                                    supplyCode,
          'BANK'                                           paymentMethodCode,
          'CNY'                                            currencyCode,
          ''||FA.FASSURE_MONEY                             paymentAmount,
          '6226682121007771188'                            bankNum,
          to_char(FA.FREC_DATE,'YYYY-MM-DD hh:mi:ss')      paymentDate,
          'DEPOSIT-D'                                      paymentTypeCode,
          ''||FA.FASSURE_MONEY                             linePaymentAmount,
          ''||FA.FBANK_SERIAL_NUM                          transactionCode
     FROM T_FN_FUND_ASSURE FA
LEFT JOIN T_FN_FUND_INFO FI ON FA.FFUND_ORG_ID = FI.FID
LEFT JOIN T_FN_OWN_CASH_SOURCE OC ON FI.FCASH_SOURCE_ID = OC.FID
)
/
