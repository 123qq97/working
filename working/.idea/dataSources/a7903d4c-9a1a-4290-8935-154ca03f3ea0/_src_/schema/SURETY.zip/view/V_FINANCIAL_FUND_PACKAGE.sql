CREATE VIEW V_FINANCIAL_FUND_PACKAGE AS (
SELECT FP.FID                                            FID,
       OC.FID                                            SOURCEHEADERID,
       FP.FID||'-'||PFR.FID                              SOURCELINEID,
       OC.FCODE                                          PARTYNUM,
       OC.FNAME                                          PARTYNAME,
       'SUPPLIER'                                        PARTYCATEGORY，
       (case
        when FI.FFUND_TYPE = 'OWN'
             then 'OWN'
        when (FI.FFUND_TYPE = 'FN' AND OC.FTYPE = 'BANK')
             then 'BANK'
        else 'PLATFORM'
             end
       )                                                 PARTYTYPE,
       to_char(OC.FCREATE_TIME,'YYYY-MM-DD hh:mi:ss')    PARTYENABLEDATE,
       FI.FFUND_CODE                                     SITECODE,
       FI.FFUND_ORG_SIMPLE_NAME                          SITENAME,
       (case
        when FP.FASSURE_RATE = 0
             then ''||0
        else '0'||FP.FASSURE_RATE/100
             end
       )                                                 DEPOSITPERCENT,
       (case
        when RF.FFUND_BUSINESS_RATE = 0
             then ''||0
        else '0'||RF.FFUND_BUSINESS_RATE/100
             end
       )                                                 INTERESTPERCENT,
       (case
        when PFR.FPREMIUM_FEE_RATE = 0
             then ''||0
        else '0'||PFR.FPREMIUM_FEE_RATE/100
             end
       )                                                 INSURANCERATE,
      (case
        when (PFR.FLOAN_DAYS = 0 or PFR.FLOAN_DAYS is null)
             then '0'
        else ''||PFR.FLOAN_DAYS
             end
       )                                                 INSURANCEDAYS,

       (case
        when RF.FCHANNEL_FEE_RATE = 0
             then ''||0
        else '0'||RF.FCHANNEL_FEE_RATE/100
             end
       )                                                 CHANNELRATE,
       (case
        when RF.FSTAMP_TAX_RATE = 0
             then ''||0
        else '0'||RF.FSTAMP_TAX_RATE/100
             end
       )                                                 STAMPDUTYRATE,
       (case
        when RF.FSERVICE_FEE_RATE = 0
             then ''||0
        else '0'||RF.FSERVICE_FEE_RATE/100
             end
       )                                                 SERVICERATE,
       to_char(FP.FENABLE_LIMIT)                         AMOUNT,
       to_char(FP.FSTART_TIME,'YYYY-MM-DD hh:mi:ss')     SITEENABLEDATE,
       to_char(FP.FEND_TIME,'YYYY-MM-DD hh:mi:ss')       SITEDISABLEDATE,
     FI.FBUSINESS_DIVISION                             companyCode
FROM T_FN_FUND_PACKAGE FP
LEFT JOIN T_FN_FUND_INFO FI ON FP.FFUND_ORG_ID = FI.FID
LEFT JOIN T_FN_OWN_CASH_SOURCE OC ON FI.FCASH_SOURCE_ID = OC.FID
LEFT JOIN T_FN_FUND_PREMIUM_FEE_RATE PFR ON FI.FID = PFR.FFUND_ORG_ID
LEFT JOIN T_FN_FUND_RATE_FORMULA RF ON FI.FID = RF.FFUND_ORG_ID
WHERE FP.FSTATUS = 'ENABLED'
  AND FI.FID IS NOT NULL
  AND OC.FID IS NOT NULL
)
/
