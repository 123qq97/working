CREATE VIEW V_FN_ASSETS_ASSURE AS SELECT FID AS FCOMPANY_ID,
       FCOMPANY_ABBR,
       NVL(ACTIVATE_CREDIT_LIMIT, 0) AS ACTIVATE_CREDIT_LIMIT,
       NVL(ING_MONEY, 0)             AS ING_MONEY,
       NVL(AVAILABLE_LIMIT, 0)       AS AVAILABLE_LIMIT,
       NVL(FASSURE_MONEY, 0)         as FASSURE_MONEY,
       NVL(UNFASSURE_MONEY, 0)       AS UNFASSURE_MONEY,
       (CASE
            WHEN ACTIVATE_CREDIT_LIMIT > 0 THEN
                NVL((ROUND(AVAILABLE_LIMIT / ACTIVATE_CREDIT_LIMIT, 4)), 0)
            ELSE 0
           END) AS VACANCY_RATE,
       NVL(FCREDIT_LIMIT, 0)         AS CREDIT_LIMIT
FROM (SELECT COMPANY.FID,
             COMPANY.FCOMPANY_ABBR,
             ASSURE.FASSURE_MONEY,
             UNASSURE.FASSURE_MONEY                           AS UNFASSURE_MONEY,
             ENABLE.ENABLE_LIMIT                              AS ACTIVATE_CREDIT_LIMIT,
             nvl(ASSETS.ING_MONEY, 0)                         as ING_MONEY,
             (ENABLE.ENABLE_LIMIT - nvl(ASSETS.ING_MONEY, 0)) AS AVAILABLE_LIMIT,
             ASSETS_INFO.FCREDIT_LIMIT
      FROM T_OPT_COMPANY COMPANY
          left join T_FN_ASSETS_INFO ASSETS_INFO ON ASSETS_INFO.FCOMPANY_ID = COMPANY.FID
        LEFT JOIN (
          SELECT SUM(ASSETS_CREDIT.FENABLE_LIMIT) ENABLE_LIMIT, ASSETS_CREDIT.FCOMPANY_ID
          FROM T_FN_ASSETS_CREDIT ASSETS_CREDIT
          WHERE ASSETS_CREDIT.FSTATUS in ('ENABLE')
          GROUP BY ASSETS_CREDIT.FCOMPANY_ID
      ) ENABLE
                         ON ENABLE.FCOMPANY_ID = COMPANY.FID
               LEFT JOIN (SELECT T.FCOMPANY_ID,
                                 SUM(CASE
                                         WHEN T.FASSURE_TYPE = 'TACKIN' THEN
                                             T.FASSURE_MONEY
                                         WHEN T.FASSURE_TYPE = 'BACK' THEN
                                             -T.FASSURE_MONEY
                                     END) AS FASSURE_MONEY
                          FROM T_FN_ASSETS_ASSURE T
                          GROUP BY T.FCOMPANY_ID) ASSURE
                         ON ASSURE.FCOMPANY_ID = COMPANY.FID
               LEFT JOIN (SELECT T.FCOMPANY_ID,
                                 SUM(CASE
                                         WHEN T.FASSURE_TYPE = 'TACKINNO' THEN
                                             T.FASSURE_MONEY
                                         WHEN T.FASSURE_TYPE = 'BACKNO' THEN
                                             -T.FASSURE_MONEY
                                     END) AS FASSURE_MONEY
                          FROM T_FN_ASSETS_ASSURE T
                          GROUP BY T.FCOMPANY_ID) UNASSURE
                         ON UNASSURE.FCOMPANY_ID = COMPANY.FID
               LEFT JOIN (SELECT A.FCOMPANY_ID,
                                 SUM(NVL(FAPPLY.FARRIVAL_ACCOUNT_TOTAL_MONEY, 0) - (CASE
                                                                                        WHEN NVL(R.FLOAN_MONEY, 0) > D.FTOTAL_REPAYMENT_MONEY
                                                                                            THEN
                                                                                            D.FTOTAL_REPAYMENT_MONEY
                                                                                        ELSE
                                                                                            NVL(R.FLOAN_MONEY, 0)
                                     END)) AS ING_MONEY
                          FROM T_SURETY_GUARANTEE A
                                   LEFT JOIN T_FN_FUND_APPLY FAPPLY
                                             ON A.FID = FAPPLY.FORDER_ID
                                   LEFT JOIN T_FN_FIN_REPAYMENT_GENERAL D
                                             ON A.FID = D.FORDER_ID
                                   LEFT JOIN (SELECT FR.FORDER_ID, SUM(FR.FLOAN_MONEY) as FLOAN_MONEY
                                              FROM T_FN_FUND_REPAYMENT FR
                                              WHERE FR.FSTATUS = 'PAY'
                                              GROUP BY FR.FORDER_ID) R
                                             ON R.FORDER_ID = A.FID
                          WHERE R.FORDER_ID IS NOT NULL
                          GROUP BY A.FCOMPANY_ID) ASSETS
                         ON ASSETS.FCOMPANY_ID = COMPANY.FID) ASSETS_INFO_V

/
