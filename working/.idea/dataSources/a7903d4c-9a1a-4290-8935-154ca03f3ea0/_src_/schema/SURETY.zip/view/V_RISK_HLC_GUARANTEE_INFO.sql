CREATE VIEW V_RISK_HLC_GUARANTEE_INFO AS (
select
  decode(trans.ftransaction_price,0,-1,round(trans.FDEPOSIT/trans.ftransaction_price,4)) SGIOT_depositRate,--定金收取比例
  decode(sign(trans.FDEPOSIT+loanbuyerinfo.sup_amount_one+loanbuyerinfo.sup_amount_two+loanbuyerinfo.mb_amout+loanbuyerinfo.pb_amout
  +loanbuyerinfo.loan_amout-trans.ftransaction_price),0,'YES','NO') SGIOT_AMOUNT,--定金+监管金额+贷款金额是否等于成交总价
  nvl2(situation.fredeem_bank_rate,round(situation.fredeem_bank_rate/100,4),null) SGS_fredeemBankRate,--赎楼比
  decode(sign(loanbuyerinfo.mb_amout+loanbuyerinfo.pb_amout+loanbuyerinfo.loan_amout-loan_detail.floan_amount),-1,'YES','NO') reply_amout,--批复金额是否小于借款金额
  decode(t_ESTATE_SELLER.is_house,0,'YES','NO') is_house, --物业用途 多条 全部房产用途是否均为住宅
  round(decode(trans.ftransaction_price,0,-1,(LOAN_BUYER2.FLOAN_MB_AMOUNT+LOAN_BUYER2.FLOAN_PB_AMOUNT)/trans.ftransaction_price),4) loan_ratio,--贷款成数
  decode(t_loan_seller.original_loan_is_back,0,'YES','NO') loan_is_back,/*floan_seller_ascription*/ --原贷款方类型是否为银行
  DECODE(t_LOAN_BUYER.new_loan_is_back,0,'YES','NO') new_loan_is_back,/*Floan_Buyer_Ascription*/   --新贷款方;BANK:银行|MECHANISM:机构
  guarant.fid order_id, --订单ID
  business_type.FTRANSACTION_TYPE  --交易类型 TRANSACTION=交易类, NOT_TRANSACTION =非交易类
  from T_SURETY_GUARANTEE guarant
  left join t_surety_business_type business_type     on guarant.fbiz_id = business_type.fid
  left join T_SURETY_G_INFO_OF_TRANSACTION trans     on guarant.fid = trans.fguarantee_id
  left join (
            SELECT sum(LOAN_BUYER.FSUPERVISION_AMOUNT_ONE) sup_amount_one,
                   sum(LOAN_BUYER.FSUPERVISION_AMOUNT_TWO) sup_amount_two,
                   sum(LOAN_BUYER.FLOAN_MB_AMOUNT)         mb_amout,
                   sum(LOAN_BUYER.FLOAN_PB_AMOUNT)         pb_amout,
                   sum(LOAN_BUYER.FLOAN_AMOUNT)            loan_amout,
                   LOAN_BUYER.Fguarantee_Id
              from T_SURETY_G_LOAN_BUYER LOAN_BUYER
              group by LOAN_BUYER.Fguarantee_Id
  ) loanbuyerinfo                                    on guarant.fid = loanbuyerinfo.fguarantee_id

  left join T_SURETY_G_GUARANTEE_SITUATION situation on guarant.fid = situation.fguarantee_id
  left join T_SURETY_G_LOAN_DETAILS loan_detail      on guarant.fid = loan_detail.fguarantee_id
  left join
           (
           SELECT sum(decode(estate_seller.festate_use,'住宅',0,1)) is_house,estate_seller.fguarantee_id
             FROM T_SURETY_G_ESTATE_SELLER estate_seller
             group by estate_seller.fguarantee_id
           ) t_estate_seller                         on guarant.fid = t_estate_seller.fguarantee_id
  left join T_SURETY_G_LOAN_BUYER LOAN_BUYER2        on guarant.fid = loan_buyer2.fguarantee_id and loan_buyer2.fsort_order=0
  left join
           (
           SELECT sum(decode(LOAN_SELLER.FLOAN_SELLER_ASCRIPTION,'BANK',0,1)) original_loan_is_back,LOAN_SELLER.Fguarantee_Id
             FROM T_SURETY_G_LOAN_SELLER loan_seller
             group by loan_seller.fguarantee_id
           ) t_loan_seller                           on guarant.fid = t_loan_seller.Fguarantee_Id
  left join
           (
           SELECT sum(decode(LOAN_BUYER_inner.FLOAN_BUYER_ASCRIPTION,'BANK',0,1)) new_loan_is_back ,LOAN_BUYER_inner.Fguarantee_Id
             FROM T_SURETY_G_LOAN_BUYER LOAN_BUYER_inner
             group by LOAN_BUYER_inner.FGUARANTEE_ID
           ) t_LOAN_BUYER                            on guarant.fid = t_LOAN_BUYER.Fguarantee_Id

)
/
