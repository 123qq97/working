CREATE VIEW V_ORDER_FCLTS AS SELECT   FGUARANTEE_ID  as forder_id,fclt_typ as fclt_type,
         TO_STRING(CAST(COLLECT(TO_CHAR(fclt_name)) AS VARCHAR2_TABLE)) AS fclt_names
         FROM T_SURETY_G_PERSON_INFO_TRADES
         GROUP BY fguarantee_id,fclt_typ
/
