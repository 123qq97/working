CREATE VIEW V_FINANCIAL_RISK_MIN_ASSURE AS (
SELECT ASSURE.FID                                        fid,
       CITY.FID                                          sourceHeaderId,
       ASSURE.FID                                        sourceLineId,
     GUA.FGUARANTEE_NUM                                documentNum,
       to_char(ASSURE.FREC_DATE,'yyyy-mm-dd')            receiptDate,
       ASSURE.FFUND_ACCOUNT_NUM                          bankNum,
       CITY.Fcity_Code                                   cityCode,
       CITY.Fcompany_Code                                cusOrgCode,
       CITY.Fsub_Company_Name                            cusOrgName,
       decode(INFO.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                           ownFlag,
       'DEPOSIT-C'                                       receiptTypeCode,
       ''||ASSURE.FASSURE_MONEY                          receiptAmount,
       'CNY'                                             currencyCode,
       ASSURE.Fbank_Serial_Num                           transactionCode,
       'BANK'                                            receiptMethodCode
     FROM T_FN_ASSETS_ASSURE ASSURE
     LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CITY ON ASSURE.FSUB_COMPANY_ID = CITY.FID
     LEFT JOIN T_FN_ASSETS_INFO INFO ON CITY.FFN_ASSETS_INFO = INFO.FID
   LEFT JOIN T_SURETY_GUARANTEE GUA ON ASSURE.FORDER_ID = GUA.FID
)
/
