CREATE VIEW V_FINANCIAL_REFUND_POUNDA AS (
SELECT   PD.FID                                         FID,
         GUA.FID                                        sourceHeaderId,
         GUA.FID                                        orderId,
         PD.FID                                         sourceLineId,
         to_char(PD.FREFUND_DATE,'yyyy-mm-dd')          refundDate,
         PD.FPAY_ACCOUNT_NUMBER                         bankNum,
     ORG.FID                                        orgId,
         ORG.FNUMBER                                    deptCode,
         ORG.FNAME                                      deptName,
     ORG.FORG_TYPE                                  orgType,
         PORG.Fnumber                                   teamId,
         PORG.FNAME                                     teamName,
         PE.FNUMBER                                     CMId,
         PE.FNAME                                       CMName,
         GUA.FCITY_CODE                                 cityCode,
         CCITY.FCOMPANY_CODE                            cusOrgCode,
         CCITY.FSUB_COMPANY_NAME                        cusOrgName,
         decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                          ownFlag,
         GT.FGUARANTEE_APPLICANT_IDS                    customerName,
         GUA.Fguarantee_Num                             documentNum,
         PD.FID                                         refundNum,
         decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                  businessTypeCode,
         decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')   productTypeCode,
        p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
         decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                  classTypeCode,
         'CHARGE'                                       refundTypeCode,
         ''||PD.FAPPLY_REFUND_MONEY                         refundAmount,
         'CNY'                                          currencyCode,
         'BANK'                                         refundMethodCode,
         DECODE(GUA.FGUARANTEE_TYPE,'INTERNAL','Y','N')   domesticFlag
         FROM T_FN_FIN_REFUND_POUNDA_DETAILS PD
         LEFT JOIN T_SURETY_GUARANTEE GUA ON PD.FORDER_ID = GUA.FID
     LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = GUA.FID
         LEFT JOIN T_ERP_PERSON PE ON PE.FID = OB.FMANAGER_ID
         LEFT JOIN T_ERP_ORG ORG ON ORG.FID = OB.FMANAGER_ORG_ID
         LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
         LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
         LEFT JOIN T_FN_ASSETS_INFO AI ON CCITY.FFN_ASSETS_INFO = AI.FID
         LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
         LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
         LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
         LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
         LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
)
/
