CREATE VIEW V_ORDER_OLD_LOAN_BANK_NEW AS SELECT fguarantee_Id                                              AS FORDER_ID,
       TO_STRING(CAST(COLLECT(TO_CHAR(parentBankName)) AS VARCHAR2_TABLE)) AS OLD_PartneLOAN_BANK,
       TO_STRING(CAST(COLLECT(TO_CHAR(bankName)) AS VARCHAR2_TABLE)) AS OLD_LOAN_BANK

FROM (
       SELECT  FGUARANTEE_ID AS fguarantee_Id,
                       PARENT_BANK.FNAME as parentBankName,
                       BANK.FNAME AS bankName
       FROM T_SURETY_G_LOAN_SELLER SELLER
              INNER JOIN T_BASE_FUND_PROVIDER BANK
                         ON BANK.FID = SELLER.FLOAN_MB_ID
              INNER JOIN T_BASE_FUND_PROVIDER PARENT_BANK
                         ON PARENT_BANK.FID = BANK.FPARENT_ID
       UNION  ALL
       SELECT
       FGUARANTEE_ID AS fguarantee_Id,
                       PARENT_BANK.FNAME as parentBankName,
                       BANK.FNAME AS bankName

       FROM T_SURETY_G_LOAN_SELLER SELLER
              INNER JOIN T_BASE_FUND_PROVIDER BANK
                         ON BANK.FID = SELLER.FLOAN_PB_ID
              INNER JOIN T_BASE_FUND_PROVIDER PARENT_BANK
                         ON PARENT_BANK.FID = BANK.FPARENT_ID
       UNION ALL
       SELECT  FGUARANTEE_ID AS fguarantee_Id,
                       PARENT_BANK.FNAME as parentBankName,
                       BANK.FNAME AS bankName
       FROM T_SURETY_G_LOAN_LENDER LENDER
              INNER JOIN T_BASE_FUND_PROVIDER BANK
                         ON BANK.FID = LENDER.FBACK_ID
              INNER JOIN T_BASE_FUND_PROVIDER PARENT_BANK
                         ON PARENT_BANK.FID = BANK.FPARENT_ID
       WHERE LENDER.FLOAN_TYPE = 'LOAN_SELLER'
     )
GROUP BY FGUARANTEE_ID
/
