CREATE TYPE               "SYSTPvn/PLrIfacbgUzoAqMCxcw==" AS TABLE OF VARCHAR2(44)
/
