CREATE TYPE               "SYSTPvdrpeyyap6DgUzoAqMBJPg==" AS TABLE OF VARCHAR2(44)
/
