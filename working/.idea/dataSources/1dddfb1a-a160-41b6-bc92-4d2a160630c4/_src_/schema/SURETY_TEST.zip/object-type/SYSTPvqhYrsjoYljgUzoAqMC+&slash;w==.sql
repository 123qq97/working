CREATE TYPE               "SYSTPvqhYrsjoYljgUzoAqMC+/w==" AS TABLE OF VARCHAR2(2017)
/
