CREATE TYPE               "SYSTPvbuJBj71ugvgUzoAqMCjqw==" AS TABLE OF VARCHAR2(44)
/
