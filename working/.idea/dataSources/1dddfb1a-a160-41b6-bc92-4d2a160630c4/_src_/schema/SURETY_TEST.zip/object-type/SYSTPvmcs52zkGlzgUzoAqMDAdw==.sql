CREATE TYPE               "SYSTPvmcs52zkGlzgUzoAqMDAdw==" AS TABLE OF VARCHAR2(200)
/
