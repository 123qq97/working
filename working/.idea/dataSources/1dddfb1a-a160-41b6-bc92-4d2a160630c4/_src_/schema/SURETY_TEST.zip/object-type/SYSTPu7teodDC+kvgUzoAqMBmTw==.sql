CREATE TYPE               "SYSTPu7teodDC+kvgUzoAqMBmTw==" AS TABLE OF VARCHAR2(44)
/
