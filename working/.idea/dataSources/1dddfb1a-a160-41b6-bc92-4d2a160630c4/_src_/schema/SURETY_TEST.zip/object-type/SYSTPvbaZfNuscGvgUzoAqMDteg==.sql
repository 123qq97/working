CREATE TYPE               "SYSTPvbaZfNuscGvgUzoAqMDteg==" AS TABLE OF VARCHAR2(200)
/
