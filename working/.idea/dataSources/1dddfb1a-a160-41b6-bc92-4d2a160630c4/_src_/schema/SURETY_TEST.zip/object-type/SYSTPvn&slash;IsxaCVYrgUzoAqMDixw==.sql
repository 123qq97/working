CREATE TYPE               "SYSTPvn/IsxaCVYrgUzoAqMDixw==" AS TABLE OF VARCHAR2(44)
/
