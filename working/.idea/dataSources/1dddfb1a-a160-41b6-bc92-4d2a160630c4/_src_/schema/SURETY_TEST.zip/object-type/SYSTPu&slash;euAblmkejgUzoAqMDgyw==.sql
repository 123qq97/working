CREATE TYPE               "SYSTPu/euAblmkejgUzoAqMDgyw==" AS TABLE OF VARCHAR2(200)
/
