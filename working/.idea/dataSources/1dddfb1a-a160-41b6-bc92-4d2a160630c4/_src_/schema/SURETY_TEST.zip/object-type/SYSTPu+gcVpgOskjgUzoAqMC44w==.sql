CREATE TYPE               "SYSTPu+gcVpgOskjgUzoAqMC44w==" AS TABLE OF VARCHAR2(200)
/
