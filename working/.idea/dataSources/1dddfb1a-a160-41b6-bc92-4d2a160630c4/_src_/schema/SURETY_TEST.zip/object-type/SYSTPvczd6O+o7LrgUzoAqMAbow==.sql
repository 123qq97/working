CREATE TYPE               "SYSTPvczd6O+o7LrgUzoAqMAbow==" AS TABLE OF VARCHAR2(44)
/
