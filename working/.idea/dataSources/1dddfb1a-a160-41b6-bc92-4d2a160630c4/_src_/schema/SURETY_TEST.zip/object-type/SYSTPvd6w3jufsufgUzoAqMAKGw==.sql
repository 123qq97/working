CREATE TYPE               "SYSTPvd6w3jufsufgUzoAqMAKGw==" AS TABLE OF VARCHAR2(44)
/
