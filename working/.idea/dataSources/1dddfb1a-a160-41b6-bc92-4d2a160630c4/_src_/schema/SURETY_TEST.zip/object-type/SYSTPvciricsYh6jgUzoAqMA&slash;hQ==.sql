CREATE TYPE               "SYSTPvciricsYh6jgUzoAqMA/hQ==" AS TABLE OF VARCHAR2(2017)
/
