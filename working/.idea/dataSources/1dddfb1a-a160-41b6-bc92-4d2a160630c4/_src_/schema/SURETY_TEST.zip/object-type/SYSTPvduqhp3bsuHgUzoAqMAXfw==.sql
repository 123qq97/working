CREATE TYPE               "SYSTPvduqhp3bsuHgUzoAqMAXfw==" AS TABLE OF VARCHAR2(2017)
/
