CREATE TYPE               "SYSTPvbugX2igugfgUzoAqMCnGw==" AS TABLE OF VARCHAR2(44)
/
