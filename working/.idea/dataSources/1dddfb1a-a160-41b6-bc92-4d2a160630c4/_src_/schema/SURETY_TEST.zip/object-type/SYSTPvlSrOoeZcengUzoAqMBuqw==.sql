CREATE TYPE               "SYSTPvlSrOoeZcengUzoAqMBuqw==" AS TABLE OF VARCHAR2(2017)
/
