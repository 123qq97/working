CREATE TYPE               "SYSTPvbarO9yjUzfgUzoAqMCzBg==" AS TABLE OF VARCHAR2(44)
/
