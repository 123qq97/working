CREATE TYPE               "SYSTPvXiagJYryxbgUzoAqMAmaA==" AS TABLE OF VARCHAR2(44)
/
