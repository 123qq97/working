CREATE TYPE               "SYSTPu/ydUdm8kFfgUzoAqMAkyg==" AS TABLE OF VARCHAR2(44)
/
