CREATE TYPE               "SYSTPvbkWvYFetzrgUzoAqMAzzw==" AS TABLE OF VARCHAR2(2017)
/
