CREATE TYPE               "SYSTPvdwhpnCxsuXgUzoAqMBMiA==" AS TABLE OF VARCHAR2(44)
/
