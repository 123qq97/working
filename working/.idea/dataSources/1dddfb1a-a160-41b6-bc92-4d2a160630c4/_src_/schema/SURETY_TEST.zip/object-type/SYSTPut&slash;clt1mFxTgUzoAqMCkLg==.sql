CREATE TYPE               "SYSTPut/clt1mFxTgUzoAqMCkLg==" AS TABLE OF VARCHAR2(44)
/
