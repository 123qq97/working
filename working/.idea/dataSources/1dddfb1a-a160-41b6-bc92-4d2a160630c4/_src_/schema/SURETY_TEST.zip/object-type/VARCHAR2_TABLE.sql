CREATE TYPE "VARCHAR2_TABLE"  as table of varchar2(4000);

/
