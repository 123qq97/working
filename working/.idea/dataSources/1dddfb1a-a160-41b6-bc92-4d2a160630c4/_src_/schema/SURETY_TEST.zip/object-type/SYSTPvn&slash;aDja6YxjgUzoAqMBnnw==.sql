CREATE TYPE               "SYSTPvn/aDja6YxjgUzoAqMBnnw==" AS TABLE OF VARCHAR2(200)
/
