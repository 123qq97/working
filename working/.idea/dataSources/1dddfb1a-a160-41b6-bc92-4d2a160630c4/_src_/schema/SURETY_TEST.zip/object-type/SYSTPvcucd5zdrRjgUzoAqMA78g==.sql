CREATE TYPE               "SYSTPvcucd5zdrRjgUzoAqMA78g==" AS TABLE OF VARCHAR2(44)
/
