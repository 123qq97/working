CREATE TYPE               "SYSTPvhrvsWCuhrfgUzoAqMC8Rw==" AS TABLE OF VARCHAR2(200)
/
