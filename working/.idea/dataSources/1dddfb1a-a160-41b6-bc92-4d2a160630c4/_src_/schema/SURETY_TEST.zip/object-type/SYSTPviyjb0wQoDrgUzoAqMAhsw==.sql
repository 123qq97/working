CREATE TYPE               "SYSTPviyjb0wQoDrgUzoAqMAhsw==" AS TABLE OF VARCHAR2(2017)
/
