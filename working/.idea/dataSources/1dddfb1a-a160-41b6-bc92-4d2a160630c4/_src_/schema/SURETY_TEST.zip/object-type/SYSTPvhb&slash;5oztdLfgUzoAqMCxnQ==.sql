CREATE TYPE               "SYSTPvhb/5oztdLfgUzoAqMCxnQ==" AS TABLE OF VARCHAR2(2017)
/
