CREATE TYPE               "SYSTPvkYSMttQlpzgUzoAqMDcwg==" AS TABLE OF VARCHAR2(200)
/
