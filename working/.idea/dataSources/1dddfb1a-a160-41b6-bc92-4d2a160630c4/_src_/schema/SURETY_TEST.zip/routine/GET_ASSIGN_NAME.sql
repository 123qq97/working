CREATE FUNCTION get_assign_name(ASSIGN_TYPE in varchar2, ASSIGN_ENTITY_ID in varchar2)
    RETURN VARCHAR2
    IS
    ENTITY_NAME VARCHAR2(200);
/*方法说明：
  传入指定类型 人员（PERSON）或者岗位不带组织ID(POSITION)或者 带组织ID的岗位（POSITION_LINK） 查找对应的人员或者岗位名称
  ASSIGN_ENTITY_ID 为多条数据，用英文逗号隔开
  WM_CONCAT（）函数是把多列转为一行返回结果
  REGEXP_SUBSTR（）函数是把ASSIGN_ENTITY_ID分割成多列
  */
BEGIN
    IF ASSIGN_TYPE = 'PERSON' THEN
        SELECT WM_CONCAT(FNAME)
        INTO ENTITY_NAME
        FROM T_ERP_PERSON
        WHERE FID IN (SELECT REGEXP_SUBSTR(ASSIGN_ENTITY_ID, '[^,]+', 1, LEVEL, 'i') AS STR
                      FROM DUAL
                      CONNECT BY LEVEL <=
                                 LENGTH(ASSIGN_ENTITY_ID) - LENGTH(REGEXP_REPLACE(ASSIGN_ENTITY_ID
                                     , ','
                                     , '')) + 1);
    END IF;
    IF ASSIGN_TYPE = 'POSITION' THEN
        SELECT WM_CONCAT(FNAME)
        INTO ENTITY_NAME
        FROM T_ERP_ORG_POSITION
        WHERE FID IN (SELECT REGEXP_SUBSTR(ASSIGN_ENTITY_ID, '[^,]+', 1, LEVEL, 'i') AS STR
                      FROM DUAL
                      CONNECT BY LEVEL <=
                                 LENGTH(ASSIGN_ENTITY_ID) - LENGTH(REGEXP_REPLACE(ASSIGN_ENTITY_ID
                                     , ','
                                     , '')) + 1);
    END IF;
    IF ASSIGN_TYPE = 'POSITION_LINK' THEN
    SELECT WM_CONCAT(P.FNAME)
    INTO ENTITY_NAME
    FROM T_ERP_ORG_POSITION_LINK PT
    LEFT JOIN T_ERP_ORG_POSITION P ON p.FID = PT.FPOSITION_ID
    WHERE PT.FID IN (SELECT REGEXP_SUBSTR(ASSIGN_ENTITY_ID, '[^,]+', 1, LEVEL, 'i') AS STR
                  FROM DUAL
                  CONNECT BY LEVEL <=
                             LENGTH(ASSIGN_ENTITY_ID) - LENGTH(REGEXP_REPLACE(ASSIGN_ENTITY_ID
                                 , ','
                                 , '')) + 1);
    END IF;
    RETURN (ENTITY_NAME);
END get_assign_name;

/
