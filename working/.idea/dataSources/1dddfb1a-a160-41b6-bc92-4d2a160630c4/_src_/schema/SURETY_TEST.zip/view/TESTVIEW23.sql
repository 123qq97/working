CREATE VIEW TESTVIEW23 AS (
       SELECT doc.fid,
              doc.fcheck_doc_lawsuit_id,
              doc.frisk_approval_id FROM t_risk_check_doc doc
       )
/
