CREATE VIEW V_FINANCIAL_REFUND_FUND_ASSURE AS (
SELECT   PD.FID                                         FID,
         GUA.FID                                        sourceHeaderId,              -- 来源系统头唯一标志
         GUA.FID                                        orderId,                    -- 订单id
         PD.FID                                         sourceLineId,               -- 来源系统行唯一标志
         to_char(PD.FREFUND_DATE,'yyyy-mm-dd')          refundDate,                 -- 退款日期(该笔退费实际收款日期，格式YYYY-MM-DD)
         PD.FPAY_ACCOUNT_NUMBER                         bankNum,                    -- 银行账号(实际退款银行账号)
     ORG.FID                                        orgId,                      --经办人所属组织id
         ORG.FNUMBER                                    deptCode,                   -- 部门CODE
         ORG.FNAME                                      deptName,                   -- 部门名称
     ORG.FORG_TYPE                                  orgType,                    --组织类型：CITY("城市公司"),
         PORG.Fnumber                                   teamId,                     -- 团队ID
         PORG.FNAME                                     teamName,                   -- 团队名称
         PE.FNUMBER                                     CMId,                       -- 客户经理工号
         PE.FNAME                                       CMName,                     -- 客户经理姓名(经办人)
         GUA.FCITY_CODE                                 cityCode,                   -- 城市编码(业务开展所在城市编码)
         CCITY.FCOMPANY_CODE                            cusOrgCode,                 -- 资产机构编码
         CCITY.FSUB_COMPANY_NAME                        cusOrgName,                 -- 资产机构名称
         decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                          ownFlag,                    -- 自营标识
         GT.FGUARANTEE_APPLICANT_IDS                    customerName,               -- 业务申请人名字(多个担保申请人情况时，传list)
         GUA.Fguarantee_Num                             documentNum,                -- 房贷云系统业务单据编号
         PD.FID                                         refundNum,                  -- 房贷云系统每条退费记录对应的退费编号(可先取“来源系统行唯一标志”)
         decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                  businessTypeCode,           -- 业务类型(资金类型)
         decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')   productTypeCode,            -- 产品类型(交易类型)
        p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
         decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                  classTypeCode,              -- 标单类型
         'CHARGE'                                       refundTypeCode,             -- 款项类型(手续费)
         ''||PD.FCONFIRM_REFUND_MONEY                         refundAmount,               -- 收费金额
         'CNY'                                          currencyCode,               -- 币种
         'BANK'                                         refundMethodCode,           -- 退款方式(默认BANK)
         DECODE(GUA.FGUARANTEE_TYPE,'INTERNAL','Y','N')   domesticFlag                -- 是否内单
         FROM T_FN_FIN_REF_BUSS_ASS_DETAIL PD
         LEFT JOIN T_SURETY_GUARANTEE GUA ON PD.FORDER_ID = GUA.FID
     LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = GUA.FID
         LEFT JOIN T_ERP_PERSON PE ON PE.FID = OB.FMANAGER_ID
         LEFT JOIN T_ERP_ORG ORG ON ORG.FID = OB.FMANAGER_ORG_ID
         LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
         LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
         LEFT JOIN T_FN_ASSETS_INFO AI ON CCITY.FFN_ASSETS_INFO = AI.FID
         LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
         LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
         LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
         LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
         LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
)
/
