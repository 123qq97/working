CREATE VIEW V_FINANCIAL_ARRIVAL_ACCOUNT_TW AS (
SELECT   TA.FID                                         FID,
         GUA.FID                                        sourceHeaderId,
         GUA.FID                                        orderId,
         TA.FID                                         sourceLineId,
         GUA.FGUARANTEE_NUM                             documentNum,
         TA.FID                                         receiptNum,
         ORG.FID                                        orgId,
         GUA.FCITY_CODE                                 cityCode,
         ORG.FNUMBER                                    deptCode,
         ORG.FNAME                                      deptName,
     ORG.FORG_TYPE                                  orgType,
         PORG.Fnumber                                   teamId,
         PORG.FNAME                                     teamName,
         PE.FNUMBER                                     CMId,
         PE.FNAME                                       CMName,
         CCITY.FCOMPANY_CODE                            cusOrgCode,
         CCITY.FSUB_COMPANY_NAME                        cusOrgName,
         GT.FGUARANTEE_APPLICANT_IDS                    customerName,
         decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                  businessTypeCode,
         decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')   productTypeCode,
p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
         decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                  classTypeCode,
         'BANK'                                         receiptMethodCode,
         'CNY'                                          currencyCode,
         ''||TA.FARRIVAL_ACCOUNT_MONEY                  receiptAmount,
         TA.FPAYEE_ACCOUNT_NUMBER                       bankNum,
         TA.FSOURCE_ACCOUNT_NUMBER                      paymentBankNum,
         to_char(TA.FARRIVAL_ACCOUNT_DATE,'YYYY-MM-DD hh:mi:ss') receiptDate,
         'DIFPRINCIPLEL'                                    receiptTypeCode,
     decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                          ownFlag,
         ''||TA.FARRIVAL_ACCOUNT_MONEY                  lineReceiptAmount
         FROM T_FN_FIN_BILLING_TWO_ACCOUNT TA
         LEFT JOIN T_SURETY_GUARANTEE GUA ON TA.FORDER_ID = GUA.FID
     LEFT JOIN T_SURETY_ORDER_BASE OB ON TA.FORDER_ID = OB.FORDER_ID
         LEFT JOIN T_ERP_PERSON PE ON OB.FMANAGER_ID = PE.FID
         LEFT JOIN T_ERP_ORG ORG ON OB.FMANAGER_ORG_ID = ORG.FID
         LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
         LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
     LEFT JOIN T_FN_ASSETS_INFO AI ON AI.FID = CCITY.FFN_ASSETS_INFO
         LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
         LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
         LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
         LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
         LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
)
/
