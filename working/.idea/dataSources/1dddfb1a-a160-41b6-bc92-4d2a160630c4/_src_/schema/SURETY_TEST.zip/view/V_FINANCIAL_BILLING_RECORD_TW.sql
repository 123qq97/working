CREATE VIEW V_FINANCIAL_BILLING_RECORD_TW AS (
SELECT br.FID                                                     FID,
       FBD.fid                                                    billingDetailsId,
       GUA.FID                                                     ORDERID,
       GUA.FID                                                     sourceHeaderId,
       br.FID                                                     sourceLineId,
       to_char(br.FBILLING_DATE,'yyyy-mm-dd')                      busFundDate,
       ORG.FID                                                     orgId,
       ba.FSOURCE_ACCOUNT_NUMBER                                         bankNum,
       GUA.FCITY_CODE                                              cityCode,
     CCITY.FSUB_COMPANY_NAME                                     cusOrgName,
     CCITY.FCOMPANY_CODE                                         cusOrgCode,
       ORG.FNUMBER                                                 deptCode,
       ORG.FNAME                                                   deptName,
     ORG.FORG_TYPE                                               orgType,
       PORG.Fnumber                                                teamId,
       PORG.FNAME                                                  teamName,
       PE.FNUMBER                                                  CMId,
       PE.FNAME                                                    CMName,
       GT.FGUARANTEE_APPLICANT_IDS                                 customerName,
       GUA.FGUARANTEE_NUM                                          documentNum,
       br.FID                                                     refundNum,
     null                                                        busFundStatus,
       decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                             businessTypeCode,
         decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')              productTypeCode,
p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
         decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                             classTypeCode,
       'PAYMENT'                                                   busFundTypeCode,
       ''||br.FBILLING_MONEY                                      busFundAmount,
       'CNY'                                                       currencyCode,
       'BANK'                                                      busFundMethod,
     DECODE(GUA.FGUARANTEE_TYPE,'INTERNAL','Y','N')              domesticFlag,
        decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                                     ownFlag
 FROM T_FN_FIN_BILLING_DETAILS FBD
left join T_FN_FIN_BILLING_RECORD br on FBD.fid = br.fbilling_details_id
left join T_FN_FIN_BILLING_ACCOUNT ba on br.fid = ba.fbilling_record_id
LEFT JOIN T_SURETY_GUARANTEE GUA ON FBD.FORDER_ID = GUA.FID
LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = GUA.FID
LEFT JOIN T_ERP_PERSON PE ON PE.FID = OB.FMANAGER_ID
LEFT JOIN T_ERP_ORG ORG ON ORG.FID = OB.FMANAGER_ORG_ID
LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
LEFT JOIN T_FN_ASSETS_INFO AI ON AI.FID = CCITY.FFN_ASSETS_INFO
LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
)
/
