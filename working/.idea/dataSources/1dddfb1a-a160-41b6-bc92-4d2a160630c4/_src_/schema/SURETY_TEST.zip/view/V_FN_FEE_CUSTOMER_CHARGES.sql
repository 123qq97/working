CREATE VIEW V_FN_FEE_CUSTOMER_CHARGES AS (
SELECT FEE_DE.FID                                        fid,                        --收费记录详情ID
       GUA.FID                                           sourceHeaderId,             --头标识
       FEE_DE.FID                                        sourceLineId,               --行标识
       to_char(FEE_DE.FCHARGE_DATE,'yyyy-mm-dd')         receiptDate,                --收费日期YYYY-MM-DD
       RISK_CITY.Fsub_Company_Name                       orgName,                    --管理组织,子公司名称
       FEE_DE.FCOMPANY_ACCOUNT_NUMBER                    bankNum,                    --银行账号
       ORG.FNUMBER                                       deptCode,                   --部门编码
       ORG.FNAME                                         deptName,                   --部门名称
       ORG2.FNUMBER                                      teamId,                     --团队ID(经办人所在组织上一级，如深圳万通下的（担保九团队）)
       ORG2.FNAME                                        teamName,                   --团队名称(经办人所在组织上一级，如深圳万通下的（担保九团队）)
       PE.FNUMBER                                        CMId,                       --客户经理工号
       PE.FNAME                                          CMName,                     --客户经理姓名
       GUA.FCITY_CODE                                    cityCode,                   --城市编码
       RISK_CITY.Fcompany_Code                           cusOrgCode,                 --资产机构编码
       RISK_CITY.FSUB_COMPANY_NAME                       cusOrgName,                 --资产机构名称
       decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                           ownFlag,                    -- 自营标识（自营：Y 非自营：N）
       GT.customerIDs                                    customerID,                 --客户ID
       GT.customerNames                                  customerName,               --客户姓名
       GUA.FGUARANTEE_NUM                                documentNum,                --业务单据编号
       FEE_DE.FID                                        receiptNum,                 --收费单号
       decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                   businessTypeCode,           --业务类型(资金类型)
       decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')    productTypeCode,            --产品类型(交易类型)
       decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                   classTypeCode,              --标单类型
       decode(FEE_DE.FFEE_TYPE,
              'ADVICE_FEE','PRE',
              'INSURANCE_FEE','INSURANCE',
              'CHANNEL_FEE','CHANNELFEE',
              'POUNDAGE_FEE','CHARGE',
              'DELAY_FEE','EXTENSION',
              'OVERDUE_FEE','DELAY','NULL')              receiptTypeCode,            --款项类型
       FEE_DE.FFEE_MONEY                                 receiptAmount,              --收费金额
       'CNY'                                             currencyCode,               --币种
       FEE_DE.FBANK_SERIAL_NUMBER                        transactionCode,            --交易流水号
       'BANK'                                            receiptMethodCode,          --收款方式(默认BANK（代表银行转账）)
       decode(FRG.FREPAYMENT_STATUS,
              'REPAYMENT_FINISH','RS',
              'YES_CONFIRM','RNS',
              'UR')                                    cusSettleStatus,            --费用结清状态(未全部回款：UR 全部回款但尚未结清费用：RNS 全部回款且结清费用：RS)
       NVL2(IOI.FID,'Y','N')                             domesticFlag                --是否内单(内单：Y 外单：N)
     FROM T_FN_FIN_FEE_DETAILS FEE_DE
LEFT JOIN T_SURETY_GUARANTEE GUA ON FEE_DE.FORDER_ID = GUA.FID
LEFT JOIN T_ERP_PERSON PE ON GUA.FCREATE_OPERATOR_ID = PE.FID
left JOIN T_ERP_ORG ORG  ON PE.FORG_ID = ORG.FID
left JOIN T_ERP_ORG ORG2  ON ORG.FPARENT_ID = ORG2.FID
LEFT JOIN T_RISK_ASSETS_CREDIT_CITY RISK_CITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = RISK_CITY.FID
LEFT JOIN T_FN_ASSETS_INFO AI ON RISK_CITY.FFN_ASSETS_INFO = AI.FID
LEFT JOIN (
          SELECT wm_concat(GTR.FID) customerIDs,                     -- 业务申请人ID
                 wm_concat(GTR.FCLT_NAME) customerNames,             -- 业务申请人名字(多个担保申请人情况时，传list)
                 GTR.FGUARANTEE_ID
            FROM T_SURETY_G_PERSON_INFO_TRADES GTR
           where GTR.FCLT_TYP = 'SELLER' AND GTR.FIS_APPLICANT = 'YES'
           GROUP BY GTR.FGUARANTEE_ID
           )GT ON GUA.FID = GT.FGUARANTEE_ID
LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
LEFT join T_RISK_PRODUCT_RATE_CONF PRC ON PRC.FPRODUCT_ID = PCM.FPRODUCT_ID AND PCM.FCITY_CODE = PRC.FCITY_CODE
LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
--LEFT JOIN T_FN_FIN_FEE_DETAILS FD ON GUA.FID = FD.FORDER_ID
LEFT JOIN T_FN_FIN_REPAYMENT_GENERAL FRG ON GUA.FID = FRG.FORDER_ID
LEFT JOIN T_SURETY_IN_ORDER_INFO IOI ON GUA.FID = IOI.FORDER_ID
    WHERE PRC.FSTATE = 'ENABLED'
      AND PCM.FSTATE = 'ENABLED'
)
/
