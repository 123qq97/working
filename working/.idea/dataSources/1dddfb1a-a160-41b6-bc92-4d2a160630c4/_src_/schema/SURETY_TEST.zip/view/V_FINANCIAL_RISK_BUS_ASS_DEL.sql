CREATE VIEW V_FINANCIAL_RISK_BUS_ASS_DEL AS (
SELECT ASSURE_RECORD.FID                                 fid,
       GUA.FID                                           sourceHeaderId,
     GUA.FID                                           orderId,
       ASSURE_RECORD.FID                                 sourceLineId,
       to_char(ASSURE_RECORD.FTAKE_DATE,'yyyy-mm-dd')    receiptDate,
       ASSURE_RECORD.FACCOUNT_NUMBER                     bankNum,
     ORG.FID                                           orgId,
       ORG.FNUMBER                                       deptCode,
       ORG.FNAME                                         deptName,
     ORG.FORG_TYPE                                     orgType,
       ORG2.FNUMBER                                      teamId,
       ORG2.FNAME                                        teamName,
       PE.FNUMBER                                        CMId,
       PE.FNAME                                          CMName,
       GUA.FCITY_CODE                                    cityCode,
       RISK_CITY.Fcompany_Code                           cusOrgCode,
       RISK_CITY.FSUB_COMPANY_NAME                       cusOrgName,
       decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                           ownFlag,
       GT.FGUARANTEE_APPLICANT_IDS                       customerName,
       GUA.FGUARANTEE_NUM                                documentNum,
       ASSURE_RECORD.FID                                 receiptNum,
       decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                   businessTypeCode,
       decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')    productTypeCode,
        p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
       decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                   classTypeCode,
       decode(ASSURE_RECORD.FFEE_TYPE,
              'SINGLE_ASSURE','DEPOSIT-A',
        'ALLOCATION_ASSURE','DEPOSIT-B',
        'CHANNEL_ASSURE','DEPOSIT-B',
        'OTHER_ASSURE','DEPOSIT-EXTRA',
        'NULL')                                    receiptTypeCode,
     (case when ASSURE_RECORD.FTAKE_MONEY > 1
           then '-'||ASSURE_RECORD.FTAKE_MONEY
       when ASSURE_RECORD.FTAKE_MONEY = 0
       then '0'
       when ASSURE_RECORD.FTAKE_MONEY < 1
       then '-0'||ASSURE_RECORD.FTAKE_MONEY
      end )                                        receiptAmount,
       'CNY'                                             currencyCode,
       'BANK'                                            receiptMethodCode,
       DECODE(GUA.FGUARANTEE_TYPE,'INTERNAL','Y','N')     domesticFlag
     FROM T_FN_BUSINESS_ASSURE_RECORD ASSURE_RECORD
LEFT JOIN T_SURETY_GUARANTEE GUA ON ASSURE_RECORD.FORDER_ID = GUA.FID
LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = GUA.FID
LEFT JOIN T_ERP_PERSON PE ON PE.FID = OB.FMANAGER_ID
left JOIN T_ERP_ORG ORG  ON ORG.FID = OB.FMANAGER_ORG_ID
left JOIN T_ERP_ORG ORG2  ON ORG.FPARENT_ID = ORG2.FID
LEFT JOIN T_RISK_ASSETS_CREDIT_CITY RISK_CITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = RISK_CITY.FID
LEFT JOIN T_FN_ASSETS_INFO AI ON RISK_CITY.FFN_ASSETS_INFO = AI.FID
LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID and PCM.FSTATE = 'ENABLED'
LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
    WHERE ASSURE_RECORD.FIS_DELETE='YES'
)
/
