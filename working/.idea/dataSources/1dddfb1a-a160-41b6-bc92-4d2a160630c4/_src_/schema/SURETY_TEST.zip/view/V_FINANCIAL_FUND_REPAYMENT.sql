CREATE VIEW V_FINANCIAL_FUND_REPAYMENT AS (
SELECT RR.FID                                                   FID,
       GUA.FID                                                  orderId,
       FRD.FBATCH_SERIAL_NUM                                    batchSerialNum,
       FR.FID                                                   sourceHeaderId,
       FRD.FID                                                   sourceLineId,
       GUA.FGUARANTEE_NUM                                       documentNum,
       RR.FID                                                   receiptNum,
       ORG.FID                                                  orgId,
       GUA.FCITY_CODE                                           cityCode,
       ORG.FNUMBER                                              deptCode,
       ORG.FNAME                                                deptName,
     ORG.FORG_TYPE                                            orgType,
       PORG.Fnumber                                             teamId,
       PORG.FNAME                                               teamName,
       PE.FNUMBER                                               CMId,
       PE.FNAME                                                 CMName,
       CCITY.FCOMPANY_CODE                                      cusOrgCode,
       CCITY.FSUB_COMPANY_NAME                                  cusOrgName,
     FUND.FFUND_CODE                                          supplyCode,
       GT.FGUARANTEE_APPLICANT_IDS                              customerName,
         decode(p.FFUND_TYPE,'CASH','XJ001',
              'AMOUNT','ED001','NULL')                          businessTypeCode,
         decode(P.FTRANSACTION_TYPE,'NOT_TRANSACTION',
              'UNTRADE','TRANSACTION','TRADE','NULL')           productTypeCode,
        p.FPRODUCT_TYPE                                   productType,
     P.FIS_SELF_FORECLOSURE                            selfForeclosure,
         decode(APP.FNORMAL_TYPE,'NORMAL',
              'STANDARD','UNSTANDRAD')                          classTypeCode,
       'BANK'                                                   paymentMethodCode,
       'CNY'                                                    currencyCode,
       (CASE WHEN FRD.FFEE_MONEY=0
             THEN '0'
             WHEN FRD.FFEE_MONEY<1
             THEN '0'||FRD.FFEE_MONEY
             ELSE ''||FRD.FFEE_MONEY END)                       paymentAmount,
       FRD.FACCOUNT_NUMBER                                      bankNum,
       to_char(FRD.FREPAYMENT_DATE,'YYYY-MM-DD hh:mi:ss')       paymentDate,
       to_char(RG.FLATEST_REPAYMENT_DATE,'YYYY-MM-DD hh:mi:ss') returnDate,
       ''||FR.FLOAN_DAYS                                        planSpendDays,
       ''||(CASE WHEN FR.FFINISH_REPAYMENT_DATE IS NOT NULL
        THEN FR.FFINISH_REPAYMENT_DATE-FR.FBILLING_DATE
        ELSE 0 END)                                             actualSpendDays,
       decode(FRD.FFEE_TYPE,
       'PRINCIPAL','PRINCIPLE',
       'INTEREST','INTEREST',
     'PREMIUM_FEE','INSURANCE',
     'CHANNEL_FEE','CHANNELFEE',
     'STAMP_TAX','STAMPDUTY')                                 paymentTypeCode,
       decode(RR.FADVICETYPE,
     'ADVANCE','Y',
     'NO_ADVANCE','N'
        ) AS                                                    isAdvancePayment,
       (CASE WHEN FRD.FFEE_MONEY=0
             THEN '0'
             WHEN FRD.FFEE_MONEY<1
             THEN '0'||FRD.FFEE_MONEY
             ELSE ''||FRD.FFEE_MONEY END)                       linePaymentAmount,
       decode(AI.FIS_SELF_SUPPORT,'YES','Y',
              'NO','N','NULL')                                  ownFlag,
       DECODE(GUA.FGUARANTEE_TYPE,'INTERNAL','Y','N')           domesticFlag
  FROM T_FN_FUND_REPAYMENT_RECORD RR
  LEFT JOIN T_FN_FUND_REPAYMENT_DETAIL FRD ON RR.FID = FRD.FREPAYMENT_RECORD_ID
  LEFT JOIN T_FN_FUND_REPAYMENT FR ON FR.FID = RR.FREPAYMENT_ID
  LEFT JOIN T_SURETY_GUARANTEE GUA ON FR.FORDER_ID = GUA.FID
  LEFT JOIN T_FN_FUND_INFO FUND ON FR.FFUND_ORG_ID = FUND.FID
  LEFT JOIN T_FN_FIN_REPAYMENT_GENERAL RG ON GUA.FID = RG.FORDER_ID
  LEFT JOIN T_SURETY_ORDER_BASE OB ON OB.FORDER_ID = GUA.FID
  LEFT JOIN T_ERP_PERSON PE ON PE.FID = OB.FMANAGER_ID
  LEFT JOIN T_ERP_ORG ORG ON ORG.FID = OB.FMANAGER_ORG_ID
  LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
  LEFT JOIN T_RISK_ASSETS_CREDIT_CITY CCITY ON GUA.FRISK_ASSETS_CREDIT_CITY_ID = CCITY.FID
  LEFT JOIN T_FN_ASSETS_INFO AI ON AI.FID = CCITY.FFN_ASSETS_INFO
  LEFT JOIN T_SURETY_BUSINESS_TYPE BT ON GUA.FBIZ_ID = BT.FID
  LEFT JOIN T_RISK_PRODUCT_CITY_MAIN PCM ON BT.FRISK_PRODUCT_CITY_ID = PCM.FID
  LEFT join T_RISK_PRODUCT P ON P.FID = PCM.FPRODUCT_ID
  LEFT JOIN T_RISK_APPROVAL APP ON GUA.FID = APP.FORDER_ID
  LEFT JOIN T_SURETY_G_GUARANTEE_SITUATION GT ON GUA.FID = GT.FGUARANTEE_ID
  WHERE FRD.FFEE_MONEY>0
)
/
