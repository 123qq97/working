CREATE VIEW V_FN_FUND_ASSURE AS SELECT FID,
       NVL(ACTIVATE_CREDIT_LIMIT, 0)                  AS ACTIVATE_CREDIT_LIMIT,
       NVL(ING_MONEY, 0)                              AS ING_MONEY,
       (NVL(ACTIVATE_CREDIT_LIMIT, 0) -
        (NVL(FAPPLY_MONEY, 0) - NVL(FLOAN_MONEY, 0))) AS ACTIVATE_LIMIT,
       (CASE
            WHEN ACTIVATE_CREDIT_LIMIT > 0 THEN ROUND(
                        (NVL(ACTIVATE_CREDIT_LIMIT, 0) - (NVL(FAPPLY_MONEY, 0) - NVL(FLOAN_MONEY, 0))) /
                        ACTIVATE_CREDIT_LIMIT, 4)
            ELSE 0 END)                               AS VACANCY_RATE /*空置率=可用额度/启用额度*/
FROM (SELECT FUND.FID                                                         FID, /*资金机构ID*/
             (CASE
                  WHEN FUND_PACKAGE.FENABLE_LIMIT > FCREDIT_LIMIT THEN FCREDIT_LIMIT
                  ELSE FUND_PACKAGE.FENABLE_LIMIT END)                     AS ACTIVATE_CREDIT_LIMIT, /*启用额度*/
             (NVL(FAPPLY.FAPPLY_MONEY, 0) - NVL(REPAYMENT.FLOAN_MONEY, 0)) AS ING_MONEY, /*在途额度=到账金额减去已解保、已结清的金额*/
             FAPPLY.FAPPLY_MONEY,
             REPAYMENT.FLOAN_MONEY
      FROM T_FN_FUND_INFO FUND
               LEFT JOIN (SELECT FUND_PACKAGE.FFUND_ORG_ID, SUM(FUND_PACKAGE.FENABLE_LIMIT) AS FENABLE_LIMIT
                          FROM T_FN_FUND_PACKAGE FUND_PACKAGE
                          WHERE FUND_PACKAGE.FSTATUS = 'ENABLED'
                          GROUP BY FUND_PACKAGE.FFUND_ORG_ID) FUND_PACKAGE ON FUND.FID = FUND_PACKAGE.FFUND_ORG_ID
               LEFT JOIN (SELECT REPAYMENT.FFUND_ORG_ID, NVL(SUM(REPAYMENT.FLOAN_MONEY), 0) AS FLOAN_MONEY
                          FROM (
                                   /*取结清明细，实际本金和实际利息分别大于应付为已结清，释放额度*/
                                   SELECT REPAYMENT.FFUND_ORG_ID , SUM(REPAYMENT_R.FPRINCIPAL) AS FLOAN_MONEY FROM T_FN_FUND_REPAYMENT REPAYMENT
                                                                                                                       LEFT JOIN T_FN_FUND_REPAYMENT_RECORD REPAYMENT_R ON REPAYMENT_R.FREPAYMENT_ID = REPAYMENT.FID
                                   WHERE REPAYMENT_R.FSTATUS IN ('PAY','NO_PAY')
                                   GROUP BY  REPAYMENT.FFUND_ORG_ID

                                   UNION ALL
                                   select FRECORD.FFUND_ORG_ID           AS FFUND_ORG_ID,
                                          FRECORD.FARRIVAL_ACCOUNT_MONEY AS FLOAN_MONEY
                                   from T_RISK_UNPROTECT UP
                                            LEFT JOIN T_FN_FUND_APPLY FAPPLY ON UP.FORDER_ID = FAPPLY.FORDER_ID
                                            LEFT JOIN T_FN_FUND_APPLY_RECORD FRECORD ON FRECORD.FFUND_APPLY_ID = FAPPLY.FID
                                   WHERE UP.FUNPROTECT_STATE = 'YES') REPAYMENT
                          GROUP BY REPAYMENT.FFUND_ORG_ID) REPAYMENT ON REPAYMENT.FFUND_ORG_ID = FUND.FID
               LEFT JOIN (SELECT RECO.FFUND_ORG_ID, SUM(case when PRODUCT.FFUND_TYPE='CASH' and RECO.FAUDIT_STATUS in('IN_AUDIT','PASS')
                                                              then RECO.FAPPLY_MONEY
                                                             when PRODUCT.FFUND_TYPE='AMOUNT' and RECO.FARRIVAL_ACCOUNT_STATUS = 'YES'
                                                              then RECO.FARRIVAL_ACCOUNT_MONEY
                                                             else 0
                                                        end
                                                       ) AS FAPPLY_MONEY
                          FROM T_FN_FUND_APPLY_RECORD RECO
                          LEFT JOIN V_RISK_PRODUCT_BUSINESS_TYPE PRODUCT
                              ON PRODUCT.FORDER_ID=RECO.FORDER_ID
                          where RECO.FDATA_STATUS='ENABLED'
                                AND NOT EXISTS ( SELECT 1  FROM T_RISK_REVOKE_ORDER RVO WHERE RVO.FORDER_ID = RECO.FORDER_ID AND RVO.FAPPROVAL_STATE = 'PASS')
                          GROUP BY RECO.FFUND_ORG_ID) FAPPLY ON FAPPLY.FFUND_ORG_ID = FUND.FID) FUND_INFO_V
/
