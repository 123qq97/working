CREATE VIEW V_FINANCIAL_SURETY_REBATE AS (
SELECT SR.FID                                                      FID,                  -- 返佣管理表id
       GUA.FID                                                     sourceHeaderId,       -- 来源系统头唯一标志
       SR.FID                                                      sourceLineId,         -- 来源系统行唯一标志
       to_char(SR.FPAYMENT_TIME,'yyyy-mm-dd')                      commissionDate,       -- 返佣日期(实际付款日期，格式YYYY-MM-DD)
       ORG.FID                                                     orgId,                -- 管理组织id
       SR.FBILLING_ACCOUNT_NUMBER                                  bankNum,              -- 付款银行账号
       ORG.FNUMBER                                                 deptCode,             -- 部门CODE
       ORG.FNAME                                                   deptName,             -- 部门名称
     ORG.FORG_TYPE                                               orgType,                    --组织类型：CITY("城市公司"),
       PORG.Fnumber                                                teamId,               -- 团队ID
       PORG.FNAME                                                  teamName,             -- 团队名称
       '待定'                                                      channelCode,          -- 渠道方编码（待房贷云开发编码规则）
       '待定'                                                      channelName,          -- 渠道方名称
       GUA.FGUARANTEE_NUM                                          documentNum,          -- 业务单据号
       'COMMISION'                                                 refundNum,            -- 款项类型
       'CNY'                                                       currencyCode,         -- 币种
       ''||SR.REBATE                                               commissionAmount,     -- 实际返佣金额
       'BANK'                                                      paymentMethod         -- 付款方式(默认BANK)
from T_SURETY_REBATE SR
LEFT JOIN T_SURETY_GUARANTEE GUA ON SR.FGUARANTEE_ID = GUA.FID
LEFT JOIN T_ERP_PERSON PE ON GUA.FCREATE_OPERATOR_ID = PE.FID
LEFT JOIN T_ERP_ORG ORG ON PE.FORG_ID = ORG.FID
LEFT JOIN T_ERP_ORG PORG ON ORG.FPARENT_ID = PORG.FID
)
/
