CREATE VIEW V_FINANCIAL_ERP_PERSON AS (
SELECT PE.FID                                                      FID,
       PE.FID                                                      sourceHeaderId,
       PE.FID                                                      sourceLineId,
       PE.FNAME                                                    employeeName,
       PE.FPHONE                                                   employeePhoneNumber,
       PE.FNUMBER                                                  employeeCode,
       PE.FEMAIL                                                   email,
       TPOSITION.FNAME                                             employeePost,
       PE.FLEVEL                                                   employeeRank,
       to_char(PE.FJOIN_DATE,'yyyy-mm-dd')                         employeeentryDate,
       to_char(PE.FLEAVE_DATE,'yyyy-mm-dd')                        employeeTermDate,
       PE.FCARD_ID                                                 employeeIDCard,
       TPORG.FNAME                                                 employeeDeptName,
       TPORG.FNUMBER                                               employeeDept,
       TPORG.FID                                                   orgId
FROM T_ERP_PERSON PE
         LEFT JOIN T_ERP_ORG TP ON PE.Forg_Id = TP.FID
         LEFT JOIN T_ERP_PERSON_ADDPOSITIONLINK TADD ON PE.FID = TADD.FPERSON_ID
         LEFT JOIN T_ERP_ORG_POSITION_LINK TLINK ON TADD.FPOSITION_LINK_ID = TLINK.FID
         LEFT JOIN T_ERP_ORG TPORG ON TLINK.FORG_ID = TPORG.FID
         LEFT JOIN T_ERP_ORG_POSITION TPOSITION ON TLINK.FPOSITION_ID = TPOSITION.FID
)
/
