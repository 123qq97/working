CREATE VIEW V_FINANCIAL_FUND_ASSURE AS (
SELECT    FA.FID                                           fid,                          -- 主键
          FI.FID                                           sourceHeaderId,               -- 来源系统头唯一标志
          FA.FID                                           sourceLineId,                 -- 来源系统行唯一标志
          -- null                                             documentNum,                  -- 业务单据号
          FA.FID                                           receiptNum,                   -- 来源单据号
          OC.FCODE                                         orgName,                      -- 业务发生公司编码
          '330200'                                         cityCode,                     -- 业务发生公司城市编码
          FI.FFUND_CODE                                    supplyCode,                   -- 资金包编码
          'BANK'                                           paymentMethodCode,            -- 付款方式
          'CNY'                                            currencyCode,                 -- 默认为人民币，CNY
          ''||FA.FASSURE_MONEY                             paymentAmount,                -- 头付款额(付款行总金额)
          '6226682121007771188'                            bankNum,                      -- 付款账号(暂时写死)
          to_char(FA.FREC_DATE,'YYYY-MM-DD hh:mi:ss')      paymentDate,                  -- 付款日期
          'DEPOSIT-D'                                      paymentTypeCode,              -- 款项类型(费用项代码，资方保证金)
          ''||FA.FASSURE_MONEY                             linePaymentAmount,            -- 收款行单个费用项金额(与头付款额一致)
      ''||FA.FBANK_SERIAL_NUM                          transactionCode               -- 交易流水号
     FROM T_FN_FUND_ASSURE FA
LEFT JOIN T_FN_FUND_INFO FI ON FA.FFUND_ORG_ID = FI.FID
LEFT JOIN T_FN_OWN_CASH_SOURCE OC ON FI.FCASH_SOURCE_ID = OC.FID
)
/
