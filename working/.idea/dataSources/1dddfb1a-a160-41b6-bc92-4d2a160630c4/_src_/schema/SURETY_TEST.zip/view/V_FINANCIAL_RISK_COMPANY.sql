CREATE VIEW V_FINANCIAL_RISK_COMPANY AS (
SELECT RC.FID                                    FID,
       CO.FID                                    sourceHeaderId,
       RC.FID                                    sourceLineId,
       RC.FCOMPANY_CODE                          partyNum,
       RC.FSUB_COMPANY_NAME                      partyName,
       'CUSTOMER'                                partyCategory,
       'PARTY'                                   partyType,
       RC.FUNIFY_SOC_CRED_CODE                   socialCode,
       'CN'                                      countryCode,
       RC.FCITY_CODE                             cityCode,
       RC.FUPDATE_TIME                           partyEnableDate,
       RC.FCOMPANY_CODE                          siteCode,
       RC.FSUB_COMPANY_NAME                      siteName,
       to_char('0'||RC.FASSURE_RATE/100)         depositPercent,
       RC.FUPDATE_TIME                           siteEnableDate,
	   RC.FBUSINESS_MODEL                        businessModel
FROM T_RISK_ASSETS_CREDIT_CITY RC
LEFT JOIN T_FN_ASSETS_INFO INF ON RC.FFN_ASSETS_INFO = INF.FID
LEFT JOIN T_OPT_COMPANY CO ON CO.FID = INF.FCOMPANY_ID
WHERE RC.FSTATE = 'ENABLED'
AND CO.FOPERATE_STATE = 'SAVE'
)
/
