CREATE VIEW V_FN_FUND_REPAYMENT_DETAIL AS select "FREPAYMENT_RECORD_ID","ACTUAL_FPRINCIPAL","ACTUAL_FPRINCIPAL_TDATE","ACTUAL_INTEREST","ACTUAL_INTEREST_TDATE","ACTUAL_PREMIUM_FEE","ACTUAL_PREMIUM_FEE_TDATE","ACTUAL_CHANNEL_FEE","ACTUAL_CHANNEL_FEE_TDATE","ACTUAL_STAMP_TAX","ACTUAL_STAMP_TAX_TDATE"
  from (select FFEE_TYPE, FFEE_MONEY, FREPAYMENT_RECORD_ID,FREPAYMENT_DATE
          from T_FN_FUND_REPAYMENT_DETAIL) pivot(sum(FFEE_MONEY),max(FREPAYMENT_DATE) TDATE for FFEE_TYPE in('PRINCIPAL' as
                                                                                  ACTUAL_FPRINCIPAL,
                                                                                  'INTEREST' AS
                                                                                  ACTUAL_INTEREST,
                                                                                  'PREMIUM_FEE' AS
                                                                                  ACTUAL_PREMIUM_FEE,
                                                                                  'CHANNEL_FEE' AS
                                                                                  ACTUAL_CHANNEL_FEE,
                                                                                  'STAMP_TAX' AS
                                                                                  ACTUAL_STAMP_TAX))
/
