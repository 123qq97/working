CREATE PACKAGE BODY PKG_REPORT_TEAM_PERFORMANCE
AS  PROCEDURE PRO_REPORT_TEAM_PERFORMANCE
(
       IN_QUERY_MONTH IN VARCHAR,       /*输入-月份YYYY-mm*/
       IN_SUB_COMPANY_NAME IN VARCHAR,  /*输入-子公司*/
       IN_TEAM_NAME IN VARCHAR,         /*输入-团队*/
       IN_DEPT_NAME IN VARCHAR,         /*输入-部门*/
       IN_LONG_NUMBERS IN VARCHAR,      /*输入-长编码，多个用逗号隔开*/
       IN_IS_AUTH_SUB_COMPANY IN VARCHAR,       /*输入-长编码，分公司权限*/
       OUT_DATASET OUT GET_CURSOR       /*输出-结果集*/
)
IS
   V_SQL  CLOB;                             /*变量-执行总SQL*/
   V_WITH_SQL  CLOB;                        /*变量-临时变量视图SQL*/
   V_ROW_RESULT_SQL  CLOB;                  /*变量-行结果集SQL*/
   V_TEAM_SUM_RESULT_SQL  CLOB;             /*变量-团队合计结果集SQL*/
   V_SUB_COMPANY_SUM_RESULT_SQL  CLOB;      /*变量-分公司合计结果集SQL*/
   V_COMPANY_SUM_RESULT_SQL  CLOB;          /*变量-总公司合计结果集SQL*/
   V_WHERE_NAME_LIKE_SQL CLOB;              /*变量-名称查询条件*/
   GLOBAL_OUT_RETURN VARCHAR2(1000);      /*异常描述*/
   GLOBAL_ERROR_EXCEPTION EXCEPTION;      /*申明异常*/
   GLOBAL_ERROR_CODE      NUMBER;         /*异常编码*/
   GLOBAL_ERROR_MSG       VARCHAR2(1000); /*异常信息*/
   GLOBAL_FLAG           VARCHAR2(10);    /*标记*/
BEGIN
   DBMS_OUTPUT.ENABLE(BUFFER_SIZE => NULL);


    /**名称查询条件*/
    V_WHERE_NAME_LIKE_SQL := '';
    IF IN_SUB_COMPANY_NAME IS NOT NULL THEN
       V_WHERE_NAME_LIKE_SQL := V_WHERE_NAME_LIKE_SQL || ' AND ROW_DATA.SUB_COMPANY_NAME LIKE ''%' || IN_SUB_COMPANY_NAME || '%'' ';
    END IF;
    IF IN_TEAM_NAME IS NOT NULL THEN
       V_WHERE_NAME_LIKE_SQL := V_WHERE_NAME_LIKE_SQL || ' AND ROW_DATA.TEAM_NAME LIKE ''%' || IN_TEAM_NAME || '%'' ';
    END IF;
    IF IN_DEPT_NAME IS NOT NULL THEN
       V_WHERE_NAME_LIKE_SQL := V_WHERE_NAME_LIKE_SQL || ' AND ROW_DATA.DEPT_NAME LIKE ''%' || IN_DEPT_NAME || '%'' ';
    END IF;

   V_WITH_SQL := '
              WITH
                /*权限*/
                V_T_AUTH AS (
                    SELECT  STR1 AS   LONG_NUMBER
                                FROM ( SELECT  DISTINCT
                                                SUBSTR(T.CA,INSTR(T.CA, '','', 1, C.LV) + 1,
                                                       INSTR(T.CA, '','', 1, C.LV + 1) -(INSTR(T.CA, '','', 1, C.LV) + 1)) AS STR1
                                       FROM (SELECT '','' || STR || '','' AS CA,LENGTH(STR || '','') -NVL(LENGTH(REPLACE(STR, '','')), 0) AS CNT FROM ((SELECT  '''|| IN_LONG_NUMBERS ||''' AS STR FROM DUAL))) T,
                                            (SELECT LEVEL LV FROM DUAL CONNECT BY LEVEL <= 1000) C
                                       WHERE C.LV <= T.CNT )),
             /*所有的部门*/
             V_T_DEPT AS (
                 SELECT DISTINCT D.COMPANY_ID,D.COMPANY_NAME,D.FULL_SUB_COMPANY_NAME AS SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.TEAM_ID,D.DEPT_NAME,D.DEPT_ID,D.DEPT_LONG_NUMBER
                 FROM V_ERP_ORG_BUSS_DEPT D
             ),
             /*所有的部门+人员*/
             V_T_DEPT_PERSON AS (
                 SELECT D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.TEAM_ID,D.DEPT_NAME,D.DEPT_ID , P.FID AS PERSON_ID, P.FNAME AS PERSON_NAME, P.FPOSITION_NAME, P.FJOIN_DATE , P.FLEAVE_DATE
                 FROM V_T_DEPT D
                     LEFT JOIN V_ERP_ORG_ALL_PERSON P ON P.FORG_ID = D.DEPT_ID
                 WHERE TO_CHAR(P.FJOIN_DATE,''YYYY-MM'') <= ''' || IN_QUERY_MONTH || '''
                       AND ( TO_CHAR(P.FLEAVE_DATE,''YYYY-MM'') >= ''' || IN_QUERY_MONTH || '''  OR P.FLEAVE_DATE is null)
             ),
             /*订单-月份*/
             V_T_MONTH_ORDER AS (
                 SELECT DISTINCT V_ORDER.*
                 FROM V_ORDER_REPAYMENT_REDEEM V_ORDER
                     INNER JOIN V_T_DEPT_PERSON P ON P.PERSON_ID = V_ORDER.PARTNER_ID
                     WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0 AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''yyyy-mm'') = ''' || IN_QUERY_MONTH || ''' ),

             /*订单-年份*/
             V_T_YEAR_ORDER AS (
                 SELECT DISTINCT V_ORDER.*
                 FROM V_ORDER_REPAYMENT_REDEEM V_ORDER
                     INNER JOIN V_T_DEPT_PERSON P ON P.PERSON_ID = V_ORDER.PARTNER_ID
                     WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0
                           AND TO_CHAR(FREDEEM_REPAMYTNT_DATE,''yyyy'') =  SUBSTR(''' || IN_QUERY_MONTH || ''',0,4) ),
             /**人员订单汇总-月份*/
            V_T_ORDER_PERSON_MONTH_SUM AS (
                 SELECT D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID,D.PERSON_ID,
                   COUNT(V_ORDER.FORDER_ID) AS TOTAL_COUNT,
                   SUM(V_ORDER.TOTAL_MONEY) AS TOTAL_MONEY,
                   /*外单*/
                   SUM( CASE WHEN V_ORDER.FGUARANTEE_TYPE != ''INTERNAL'' THEN TOTAL_MONEY ELSE 0 END ) AS OUT_MONEY
              FROM V_T_MONTH_ORDER V_ORDER
                   LEFT JOIN V_T_DEPT_PERSON D ON D.PERSON_ID = V_ORDER.PARTNER_ID
                   GROUP BY D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID, D.PERSON_ID),
            /**人员订单汇总-年份*/
            V_T_ORDER_PERSON_YEAR_SUM AS (
                 SELECT D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID,D.PERSON_ID,
                   COUNT(V_ORDER.FORDER_ID) AS TOTAL_COUNT,
                   SUM(V_ORDER.TOTAL_MONEY) AS TOTAL_MONEY,
                   /*外单*/
                   SUM( CASE WHEN V_ORDER.FGUARANTEE_TYPE != ''INTERNAL'' THEN TOTAL_MONEY ELSE 0 END ) AS OUT_MONEY
              FROM V_T_YEAR_ORDER V_ORDER
                   LEFT JOIN V_T_DEPT_PERSON D ON D.PERSON_ID = V_ORDER.PARTNER_ID
                   GROUP BY D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID, D.PERSON_ID),
            /**部门订单汇总-月份*/
            V_T_ORDER_DEPT_MONTH_SUM AS (
                 SELECT D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID,
                   SUM(V_ORDER.TOTAL_MONEY) AS TOTAL_MONEY,
                   SUM(V_ORDER.OUT_MONEY) AS OUT_MONEY
              FROM V_T_ORDER_PERSON_MONTH_SUM V_ORDER
                   LEFT JOIN V_T_DEPT_PERSON D ON D.PERSON_ID = V_ORDER.PERSON_ID
                   GROUP BY D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID),
            /**部门订单汇总-年份*/
            V_T_ORDER_DEPT_YEAR_SUM AS (
                 SELECT D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID,
                   SUM(V_ORDER.TOTAL_MONEY) AS TOTAL_MONEY,
                   SUM(V_ORDER.OUT_MONEY) AS OUT_MONEY
              FROM V_T_ORDER_PERSON_YEAR_SUM V_ORDER
                   LEFT JOIN V_T_DEPT_PERSON D ON D.PERSON_ID = V_ORDER.PERSON_ID
                   GROUP BY D.COMPANY_ID,D.COMPANY_NAME,D.SUB_COMPANY_NAME,D.SUB_COMPANY_ID,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID),
            /**部门总人数-月份*/
            DEPT_PERSON_MONTH_SUM AS (
                SELECT COMPANY_ID,COMPANY_NAME,SUB_COMPANY_NAME,SUB_COMPANY_ID,TEAM_NAME,TEAM_ID,DEPT_NAME,DEPT_ID , COUNT(1) AS PERSON_COUNT FROM V_T_DEPT_PERSON D
                GROUP BY COMPANY_ID,COMPANY_NAME,SUB_COMPANY_NAME,SUB_COMPANY_ID,TEAM_NAME,TEAM_ID,DEPT_NAME,DEPT_ID
            ),
            /**部门总人数-年份*/
            DEPT_PERSON_YEAR_SUM AS (
                 SELECT DEPT_ID , COUNT(1) AS PERSON_COUNT
                   FROM V_T_DEPT D
                       LEFT JOIN V_ERP_ORG_ALL_PERSON P ON P.FORG_ID = D.DEPT_ID
                   WHERE TO_CHAR(P.FJOIN_DATE,''YYYY'') <= SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)
                         AND ( TO_CHAR(P.FLEAVE_DATE,''YYYY'') >= SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)  or P.FLEAVE_DATE is null)
                   GROUP BY DEPT_ID
            ),
            /**部门订单汇总（月+年）+目标业绩*/
            DEPT_ORDER_SUM AS (
                SELECT P_M.COMPANY_ID,P_M.COMPANY_NAME,P_M.SUB_COMPANY_NAME,P_M.SUB_COMPANY_ID,P_M.TEAM_NAME,P_M.TEAM_ID,P_M.DEPT_NAME,P_M.DEPT_ID,
                       DEPT_P.PERSON_NAME AS DEPT_MANAGER_NAME,
                       TEAM_P.PERSON_NAME AS TEAM_MANAGER_NAME,
                       P_M.PERSON_COUNT AS MONTH_PERSON_JOIN_COUNT,
                        /*月份==========*/
                       NVL(PP_M.FPERFORMANCE_OBJECTIVE,0) AS MONTH_TOTAL_TARGER_MONEY,
                       NVL(O_M.TOTAL_MONEY,0) AS MONTH_FINISH_TARGER_MONEY,
                       CASE WHEN PP_M.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(NVL(O_M.TOTAL_MONEY,0) /  PP_M.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS MONTH_FINISH_TARGER_RATE,
                       CASE WHEN P_M.PERSON_COUNT > 0 THEN ROUND(NVL(O_M.TOTAL_MONEY,0) /  P_M.PERSON_COUNT,2)  ELSE 0 END AS MONTH_PERSON_AVG_MONEY,
                       /*月份-外单*/
                       NVL(O_M.OUT_MONEY,0) AS MONTH_OUT_MONEY,
                       CASE WHEN P_M.PERSON_COUNT > 0 THEN ROUND(NVL(O_M.OUT_MONEY,0) /  P_M.PERSON_COUNT,2) ELSE 0 END AS MONTH_OUT_PERSON_AVG_MONEY,
                       CASE WHEN O_M.OUT_MONEY > 0 THEN ROUND(NVL(O_M.OUT_MONEY,0) /  O_M.TOTAL_MONEY,4) * 100  ELSE 0 END AS MONTH_OUT_RATE,
                        /*年份==========*/
                       P_Y.PERSON_COUNT AS YEAR_PERSON_JOIN_COUNT,
                       NVL(PP_Y.FPERFORMANCE_OBJECTIVE,0) AS YEAR_TOTAL_TARGER_MONEY,
                       NVL(O_Y.TOTAL_MONEY,0) AS YEAR_FINISH_TARGER_MONEY,
                       CASE WHEN PP_Y.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(NVL(O_Y.TOTAL_MONEY,0) /  PP_Y.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS YEAR_FINISH_TARGER_RATE,
                       CASE WHEN P_Y.PERSON_COUNT > 0 THEN ROUND(NVL(O_Y.TOTAL_MONEY,0) /  P_Y.PERSON_COUNT,2)  ELSE 0 END AS YEAR_PERSON_AVG_MONEY,
                       /*年份外单*/
                       NVL(O_Y.OUT_MONEY,0) AS YEAR_OUT_MONEY,
                       CASE WHEN P_Y.PERSON_COUNT > 0 THEN ROUND(NVL(O_Y.OUT_MONEY,0) /  P_Y.PERSON_COUNT,2) ELSE 0 END AS YEAR_OUT_PERSON_AVG_MONEY,
                       CASE WHEN O_Y.OUT_MONEY > 0 THEN ROUND(NVL(O_Y.OUT_MONEY,0) /  O_Y.TOTAL_MONEY,4) * 100  ELSE 0 END AS YEAR_OUT_RATE
                FROM DEPT_PERSON_MONTH_SUM P_M
                     LEFT JOIN DEPT_PERSON_YEAR_SUM P_Y ON P_Y.DEPT_ID = P_M.DEPT_ID
                     LEFT JOIN V_T_ORDER_DEPT_MONTH_SUM O_M ON O_M.DEPT_ID = P_M.DEPT_ID
                     LEFT JOIN V_T_ORDER_DEPT_YEAR_SUM O_Y ON O_Y.DEPT_ID = P_M.DEPT_ID
                     LEFT JOIN V_ERP_ORG_MANAGER_PERSON DEPT_P ON DEPT_P.ORG_ID = P_M.DEPT_ID
                     LEFT JOIN V_ERP_ORG_MANAGER_PERSON TEAM_P ON TEAM_P.ORG_ID = P_M.TEAM_ID
                     LEFT JOIN T_ERP_ORG_PERFORMANCE PP_M ON PP_M.FORG_ID = P_M.DEPT_ID AND PP_M.FSTATUS =''ENABLED''  AND PP_M.FPERFORMANCE_TYPE = ''MONTH''
                              AND  TO_CHAR(TO_DATE(PP_M.FYEAR || ''-'' || PP_M.FMONTH,''yyyy-mm''),''yyyy-MM'') = ''' || IN_QUERY_MONTH || '''
                     LEFT JOIN T_ERP_ORG_PERFORMANCE PP_Y ON PP_Y.FORG_ID = P_M.DEPT_ID AND PP_Y.FSTATUS =''ENABLED''  AND PP_Y.FPERFORMANCE_TYPE = ''YEAR''
                              AND PP_Y.FYEAR = SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)
            ),
            /**部门订单汇总（月+年）+目标业绩+排名*/
            DEPT_ORDER_SUM_RANK AS (
                SELECT ORDER_SUM.* ,
                       ROW_NUMBER() OVER(PARTITION BY COMPANY_ID,SUB_COMPANY_ID ORDER BY NVL(MONTH_FINISH_TARGER_RATE,0) DESC, NVL(MONTH_FINISH_TARGER_MONEY,0) DESC ) AS MONTH_RANK_INDEX,
                       ROW_NUMBER() OVER(PARTITION BY COMPANY_ID,SUB_COMPANY_ID ORDER BY NVL(YEAR_FINISH_TARGER_RATE ,0) DESC, NVL(YEAR_FINISH_TARGER_MONEY,0) DESC ) AS YEAR_RANK_INDEX,
                       NULL AS MONTH_DEPT_AVG_MONEY,
                       NULL AS YEAR_DEPT_AVG_MONEY
                FROM DEPT_ORDER_SUM ORDER_SUM
            ),
            /**分公司内部门 排名第一和最后一名*/
            SUB_COMPANY_DEPT_MIN_MAX_RANK AS (
                SELECT COMPANY_ID,SUB_COMPANY_ID,
                       SUB_COMPANY_ID || ''-'' || MIN_MONTH_RANK_INDEX AS MIN_MONTH_RANK_INDEX,
                       SUB_COMPANY_ID || ''-'' || MAX_MONTH_RANK_INDEX AS MAX_MONTH_RANK_INDEX
                FROM(
                    SELECT COMPANY_ID,COMPANY_NAME,SUB_COMPANY_NAME,SUB_COMPANY_ID,
                           MIN(MONTH_RANK_INDEX) MIN_MONTH_RANK_INDEX,
                           MAX(MONTH_RANK_INDEX) MAX_MONTH_RANK_INDEX
                    FROM DEPT_ORDER_SUM_RANK ORDER_SUM
                    GROUP BY COMPANY_ID,COMPANY_NAME,SUB_COMPANY_NAME,SUB_COMPANY_ID
                ) TEMP
            ),
            /**团队业绩汇总+目标业绩*/
            TEAM_ORDER_SUM AS (
               SELECT  TEMP.COMPANY_ID,TEMP.COMPANY_NAME,TEMP.SUB_COMPANY_NAME,TEMP.SUB_COMPANY_ID,TEMP.TEAM_NAME , TEMP.TEAM_ID,
                       PP_M.FPERFORMANCE_OBJECTIVE AS MONTH_TOTAL_TARGER_MONEY,
                       TEMP.MONTH_FINISH_TARGER_MONEY,
                       /*部均*/
                       CASE WHEN TEMP.DEPT_COUNT >  0 THEN ROUND(TEMP.MONTH_FINISH_TARGER_MONEY /  TEMP.DEPT_COUNT,2) ELSE 0 END AS MONTH_DEPT_AVG_MONEY,
                       CASE WHEN PP_M.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(TEMP.MONTH_FINISH_TARGER_MONEY /  PP_M.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS MONTH_FINISH_TARGER_RATE,
                       PP_Y.FPERFORMANCE_OBJECTIVE AS YEAR_TOTAL_TARGER_MONEY,
                       TEMP.YEAR_FINISH_TARGER_MONEY,
                       CASE WHEN TEMP.DEPT_COUNT >  0 THEN ROUND(TEMP.YEAR_FINISH_TARGER_MONEY /  TEMP.DEPT_COUNT,2) ELSE 0 END AS YEAR_DEPT_AVG_MONEY,
                       CASE WHEN PP_Y.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(TEMP.YEAR_FINISH_TARGER_MONEY /  PP_Y.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS YEAR_FINISH_TARGER_RATE
               FROM (
                  SELECT P_M.COMPANY_ID,P_M.COMPANY_NAME,P_M.SUB_COMPANY_NAME,P_M.SUB_COMPANY_ID,P_M.TEAM_NAME , P_M.TEAM_ID,
                         COUNT(P_M.DEPT_ID) DEPT_COUNT,
                         /*月份==========*/
                         SUM(O_M.TOTAL_MONEY) AS MONTH_FINISH_TARGER_MONEY,
                         /*年份==========*/
                         SUM(O_Y.TOTAL_MONEY) AS YEAR_FINISH_TARGER_MONEY
                  FROM DEPT_PERSON_MONTH_SUM P_M
                       LEFT JOIN V_T_ORDER_DEPT_MONTH_SUM O_M ON O_M.DEPT_ID = P_M.DEPT_ID
                       LEFT JOIN V_T_ORDER_DEPT_YEAR_SUM O_Y ON O_Y.DEPT_ID = P_M.DEPT_ID
                  GROUP BY P_M.COMPANY_ID,P_M.COMPANY_NAME,P_M.SUB_COMPANY_NAME,P_M.SUB_COMPANY_ID,P_M.TEAM_NAME , P_M.TEAM_ID
                ) TEMP
               LEFT JOIN T_ERP_ORG_PERFORMANCE PP_M ON PP_M.FORG_ID = TEMP.TEAM_ID AND PP_M.FSTATUS =''ENABLED''  AND PP_M.FPERFORMANCE_TYPE = ''MONTH''
               LEFT JOIN T_ERP_ORG_PERFORMANCE PP_Y ON PP_Y.FORG_ID = TEMP.TEAM_ID AND PP_Y.FSTATUS =''ENABLED''  AND PP_Y.FPERFORMANCE_TYPE = ''YEAR''
                              AND PP_Y.FYEAR = SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)
            ),
            /**分公司业绩汇总+目标业绩*/
            SUB_COMPANY_ORDER_SUM AS (
               SELECT  TEMP.COMPANY_ID,TEMP.COMPANY_NAME,TEMP.SUB_COMPANY_NAME,TEMP.SUB_COMPANY_ID,
                       TEMP.MONTH_FINISH_TARGER_MONEY,
                       PP_Y.FPERFORMANCE_OBJECTIVE AS YEAR_TOTAL_TARGER_MONEY,
                       TEMP.YEAR_FINISH_TARGER_MONEY,
                       CASE WHEN PP_Y.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(TEMP.YEAR_FINISH_TARGER_MONEY /  PP_Y.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS YEAR_FINISH_TARGER_RATE
               FROM (
                  SELECT P_M.COMPANY_ID,P_M.COMPANY_NAME,P_M.SUB_COMPANY_NAME,P_M.SUB_COMPANY_ID,
                         SUM(O_M.TOTAL_MONEY) AS MONTH_FINISH_TARGER_MONEY,
                         SUM(O_Y.TOTAL_MONEY) AS YEAR_FINISH_TARGER_MONEY
                  FROM DEPT_PERSON_MONTH_SUM P_M
                       LEFT JOIN V_T_ORDER_DEPT_MONTH_SUM O_M ON O_M.DEPT_ID = P_M.DEPT_ID
                       LEFT JOIN V_T_ORDER_DEPT_YEAR_SUM O_Y ON O_Y.DEPT_ID = P_M.DEPT_ID
                  GROUP BY P_M.COMPANY_ID,P_M.COMPANY_NAME,P_M.SUB_COMPANY_NAME,P_M.SUB_COMPANY_ID
                ) TEMP
               LEFT JOIN T_ERP_ORG_PERFORMANCE PP_Y ON PP_Y.FORG_ID = TEMP.SUB_COMPANY_ID AND PP_Y.FSTATUS =''ENABLED''  AND PP_Y.FPERFORMANCE_TYPE = ''YEAR''
                              AND PP_Y.FYEAR = SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)
            ),
            /**商户业绩汇总+目标业绩*/
            COMPANY_ORDER_SUM AS (
               SELECT  TEMP.COMPANY_ID,
                       TEMP.COMPANY_NAME,
                       TEMP.MONTH_FINISH_TARGER_MONEY,
                       PP_Y.FPERFORMANCE_OBJECTIVE AS YEAR_TOTAL_TARGER_MONEY,
                       TEMP.YEAR_FINISH_TARGER_MONEY,
                       CASE WHEN PP_Y.FPERFORMANCE_OBJECTIVE > 0 THEN ROUND(TEMP.YEAR_FINISH_TARGER_MONEY /  PP_Y.FPERFORMANCE_OBJECTIVE,4) * 100  ELSE 0 END AS YEAR_FINISH_TARGER_RATE
               FROM (
                  SELECT P_M.COMPANY_ID,P_M.COMPANY_NAME,
                         SUM(O_M.TOTAL_MONEY) AS MONTH_FINISH_TARGER_MONEY,
                         SUM(O_Y.TOTAL_MONEY) AS YEAR_FINISH_TARGER_MONEY
                  FROM DEPT_PERSON_MONTH_SUM P_M
                       LEFT JOIN V_T_ORDER_DEPT_MONTH_SUM O_M ON O_M.DEPT_ID = P_M.DEPT_ID
                       LEFT JOIN V_T_ORDER_DEPT_YEAR_SUM O_Y ON O_Y.DEPT_ID = P_M.DEPT_ID
                  GROUP BY P_M.COMPANY_ID,P_M.COMPANY_NAME
                ) TEMP
               LEFT JOIN T_ERP_ORG_PERFORMANCE PP_Y ON PP_Y.FORG_ID = TEMP.COMPANY_ID AND PP_Y.FSTATUS =''ENABLED''  AND PP_Y.FPERFORMANCE_TYPE = ''YEAR''
                              AND PP_Y.FYEAR = SUBSTR(''' || IN_QUERY_MONTH || ''',0,4)
            ),
            /**数据行+权限过滤*/
            V_ROW_RESULT AS (
                  SELECT  1 AS DATA_TYPE , ''行数据'' AS DATA_TYPE_NAME ,
                          ROW_DATA.*
                  FROM DEPT_ORDER_SUM_RANK ROW_DATA
                  WHERE 1 = 1
                        AND ROW_DATA.DEPT_ID IN ( SELECT DEPT_ID  FROM V_T_DEPT D   INNER JOIN  V_T_AUTH A ON INSTR(D.DEPT_LONG_NUMBER, A.LONG_NUMBER)> 0 )
                  ' || V_WHERE_NAME_LIKE_SQL || '
            ),
            /**数据行+权限过滤+第一名+最后一名*/
            V_ROW_RESULT_MIN_MIX AS (
                  SELECT  1 AS DATA_TYPE , ''行数据'' AS DATA_TYPE_NAME ,
                          ROW_DATA.*
                  FROM DEPT_ORDER_SUM_RANK ROW_DATA
                  WHERE 1 = 1
                      AND ROW_DATA.DEPT_ID IN ( SELECT DEPT_ID  FROM V_T_DEPT D   INNER JOIN  V_T_AUTH A ON INSTR(D.DEPT_LONG_NUMBER, A.LONG_NUMBER)> 0 )
                      OR (
                          ROW_DATA.SUB_COMPANY_ID IN ( SELECT SUB_COMPANY_ID  FROM V_T_DEPT D   INNER JOIN  V_T_AUTH A ON INSTR(D.DEPT_LONG_NUMBER, A.LONG_NUMBER)> 0 )
                          AND
                          (  ROW_DATA.SUB_COMPANY_ID || ''-'' || ROW_DATA.MONTH_RANK_INDEX IN ( SELECT MIN_MONTH_RANK_INDEX FROM SUB_COMPANY_DEPT_MIN_MAX_RANK)
                             OR ROW_DATA.SUB_COMPANY_ID || ''-'' || ROW_DATA.MONTH_RANK_INDEX IN ( SELECT MAX_MONTH_RANK_INDEX FROM SUB_COMPANY_DEPT_MIN_MAX_RANK)
                          )
                      )
            )
   ';

   /*行结果集SQL*/
   V_ROW_RESULT_SQL :='SELECT ROW_DATA.* FROM V_ROW_RESULT_MIN_MIX ROW_DATA  WHERE 1 = 1 ' || V_WHERE_NAME_LIKE_SQL || ' ';

   /*团队合计结果集SQL*/
   V_TEAM_SUM_RESULT_SQL := 'SELECT  2 AS DATA_TYPE , ''团队合计'' AS DATA_TYPE_NAME ,
                                   ROW_DATA.COMPANY_ID,ROW_DATA.COMPANY_NAME,ROW_DATA.SUB_COMPANY_NAME,ROW_DATA.SUB_COMPANY_ID,
                                   ROW_DATA.TEAM_NAME || ''合计'' AS  TEAM_NAME, ROW_DATA.TEAM_ID,
                                   NULL AS DEPT_NAME,NULL AS DEPT_ID,
                                   NULL AS DEPT_MANAGER_NAME,
                                   NULL AS TEAM_MANAGER_NAME,
                                   NULL AS MONTH_PERSON_JOIN_COUNT,
                                    /*月份==========*/
                                   NULL AS MONTH_TOTAL_TARGER_MONEY,
                                   NVL(ROW_DATA.MONTH_FINISH_TARGER_MONEY,0) AS MONTH_FINISH_TARGER_MONEY,
                                   NULL AS MONTH_FINISH_TARGER_RATE,
                                   NULL AS MONTH_PERSON_AVG_MONEY,
                                   /*月份-外单*/
                                   NULL AS MONTH_OUT_MONEY,
                                   NULL AS MONTH_OUT_PERSON_AVG_MONEY,
                                   NULL AS MONTH_OUT_RATE,
                                    /*年份==========*/
                                   NULL AS YEAR_PERSON_JOIN_COUNT,
                                   ROW_DATA.YEAR_TOTAL_TARGER_MONEY,
                                   NVL(ROW_DATA.YEAR_FINISH_TARGER_MONEY,0) AS YEAR_FINISH_TARGER_MONEY,
                                   ROW_DATA.YEAR_FINISH_TARGER_RATE,
                                   NULL AS YEAR_PERSON_AVG_MONEY,
                                   /*年份外单*/
                                   NULL AS YEAR_OUT_MONEY,
                                   NULL AS YEAR_OUT_PERSON_AVG_MONEY,
                                   NULL AS YEAR_OUT_RATE,

                                   NULL AS MONTH_RANK_INDEX,
                                   NULL AS YEAR_RANK_INDEX,
                                   /*部均*/
                                   ROW_DATA.MONTH_DEPT_AVG_MONEY,
                                   ROW_DATA.YEAR_DEPT_AVG_MONEY
                            FROM TEAM_ORDER_SUM ROW_DATA
                            WHERE  TEAM_ID IN (SELECT TEAM_ID FROM V_ROW_RESULT )';

   /*分公司合计结果集SQL*/
   V_SUB_COMPANY_SUM_RESULT_SQL := 'SELECT  3 AS DATA_TYPE , ''分公司合计'' AS DATA_TYPE_NAME ,
                                   ROW_DATA.COMPANY_ID,ROW_DATA.COMPANY_NAME,ROW_DATA.SUB_COMPANY_NAME,ROW_DATA.SUB_COMPANY_ID,
                                   NULL AS TEAM_NAME, NULL AS TEAM_ID,
                                   NULL AS DEPT_NAME,NULL AS DEPT_ID,
                                   NULL AS DEPT_MANAGER_NAME,
                                   NULL AS TEAM_MANAGER_NAME,
                                   NULL AS MONTH_PERSON_JOIN_COUNT,
                                    /*月份==========*/
                                   NULL AS MONTH_TOTAL_TARGER_MONEY,
                                   NVL(ROW_DATA.MONTH_FINISH_TARGER_MONEY,0) AS MONTH_FINISH_TARGER_MONEY,
                                   NULL AS MONTH_FINISH_TARGER_RATE,
                                   NULL AS MONTH_PERSON_AVG_MONEY,
                                   /*月份-外单*/
                                   NULL AS MONTH_OUT_MONEY,
                                   NULL AS MONTH_OUT_PERSON_AVG_MONEY,
                                   NULL AS MONTH_OUT_RATE,
                                    /*年份==========*/
                                   NULL AS YEAR_PERSON_JOIN_COUNT,
                                   ROW_DATA.YEAR_TOTAL_TARGER_MONEY,
                                   NVL(ROW_DATA.YEAR_FINISH_TARGER_MONEY,0) AS YEAR_FINISH_TARGER_MONEY,
                                   ROW_DATA.YEAR_FINISH_TARGER_RATE,
                                   NULL AS YEAR_PERSON_AVG_MONEY,
                                   /*年份外单*/
                                   NULL AS YEAR_OUT_MONEY,
                                   NULL AS YEAR_OUT_PERSON_AVG_MONEY,
                                   NULL AS YEAR_OUT_RATE,

                                   NULL AS MONTH_RANK_INDEX,
                                   NULL AS YEAR_RANK_INDEX,
                                   /*部均*/
                                   NULL AS MONTH_DEPT_AVG_MONEY,
                                   NULL AS YEAR_DEPT_AVG_MONEY
                            FROM SUB_COMPANY_ORDER_SUM ROW_DATA
                            WHERE  SUB_COMPANY_ID IN (SELECT SUB_COMPANY_ID FROM V_ROW_RESULT)';

   /*总公司合计结果集SQL*/
   V_COMPANY_SUM_RESULT_SQL := 'SELECT  4 AS DATA_TYPE , ROW_DATA.COMPANY_NAME || ''总公司合计'' AS DATA_TYPE_NAME ,
                                   ROW_DATA.COMPANY_ID,ROW_DATA.COMPANY_NAME,
                                   NULL AS SUB_COMPANY_ID,NULL AS SUB_COMPANY_NAME,
                                   ROW_DATA.COMPANY_NAME || ''总公司合计'' AS TEAM_NAME, NULL AS TEAM_ID,
                                   NULL AS DEPT_NAME,NULL AS DEPT_ID,
                                   NULL AS DEPT_MANAGER_NAME,
                                   NULL AS TEAM_MANAGER_NAME,
                                   NULL AS MONTH_PERSON_JOIN_COUNT,
                                    /*月份==========*/
                                   NULL AS MONTH_TOTAL_TARGER_MONEY,
                                   ROW_DATA.MONTH_FINISH_TARGER_MONEY,
                                   NULL AS MONTH_FINISH_TARGER_RATE,
                                   NULL AS MONTH_PERSON_AVG_MONEY,
                                   /*月份-外单*/
                                   NULL AS MONTH_OUT_MONEY,
                                   NULL AS MONTH_OUT_PERSON_AVG_MONEY,
                                   NULL AS MONTH_OUT_RATE,
                                    /*年份==========*/
                                   NULL AS YEAR_PERSON_JOIN_COUNT,
                                   ROW_DATA.YEAR_TOTAL_TARGER_MONEY,
                                   ROW_DATA.YEAR_FINISH_TARGER_MONEY,
                                   ROW_DATA.YEAR_FINISH_TARGER_RATE,
                                   NULL AS YEAR_PERSON_AVG_MONEY,
                                   /*年份外单*/
                                   NULL AS YEAR_OUT_MONEY,
                                   NULL AS YEAR_OUT_PERSON_AVG_MONEY,
                                   NULL AS YEAR_OUT_RATE,

                                   NULL AS MONTH_RANK_INDEX,
                                   NULL AS YEAR_RANK_INDEX,
                                   /*部均*/
                                   NULL AS MONTH_DEPT_AVG_MONEY,
                                   NULL AS YEAR_DEPT_AVG_MONEY
                            FROM COMPANY_ORDER_SUM ROW_DATA
                            WHERE  COMPANY_ID IN (SELECT COMPANY_ID FROM V_ROW_RESULT)';


   /*执行总SQL*/
   V_SQL := V_WITH_SQL ||   ' '   ||  V_ROW_RESULT_SQL  || ' UNION ALL ' ||  V_TEAM_SUM_RESULT_SQL ;


   /**公司权限处理*/
   IF IN_IS_AUTH_SUB_COMPANY = 'YES' THEN
      V_SQL :=  V_SQL  || ' UNION ALL ' ||  V_SUB_COMPANY_SUM_RESULT_SQL  || ' UNION ALL ' ||  V_COMPANY_SUM_RESULT_SQL;
   END IF;


   /*设置排序*/
   --V_SQL := 'SELECT * FROM (' || V_SQL || ')  V_SQL ORDER BY COMPANY_ID , TEAM_NAME , DEPT_ID  ,MONTH_RANK_INDEX ';
   V_SQL := 'SELECT T.* FROM (' || V_SQL || ') T ORDER BY  COMPANY_NAME ,COMPANY_ID, SUB_COMPANY_NAME ,SUB_COMPANY_ID, TEAM_NAME ,TEAM_ID, DEPT_ID , DATA_TYPE ,MONTH_RANK_INDEX ';

   DBMS_OUTPUT.PUT_LINE('执行总SQL:>>>>>>>==================');


   DBMS_OUTPUT.PUT_LINE( V_WITH_SQL);
   DBMS_OUTPUT.PUT_LINE( 'SELECT T.* FROM (');
   DBMS_OUTPUT.PUT_LINE( V_ROW_RESULT_SQL);
   DBMS_OUTPUT.PUT_LINE( 'UNION ALL');
   DBMS_OUTPUT.PUT_LINE( V_TEAM_SUM_RESULT_SQL);
   DBMS_OUTPUT.PUT_LINE( 'UNION ALL');
   DBMS_OUTPUT.PUT_LINE( V_SUB_COMPANY_SUM_RESULT_SQL);
   DBMS_OUTPUT.PUT_LINE( 'UNION ALL');
   DBMS_OUTPUT.PUT_LINE( V_COMPANY_SUM_RESULT_SQL);
   DBMS_OUTPUT.PUT_LINE( ') T');
   DBMS_OUTPUT.PUT_LINE( ' ORDER BY COMPANY_NAME , SUB_COMPANY_NAME , TEAM_NAME , DEPT_ID , DATA_TYPE ,MONTH_RANK_INDEX ');

   /*执行*/
   OPEN OUT_DATASET FOR V_SQL;
EXCEPTION
      /*异常捕捉，不要把有需要的代码放在异常捕捉后面，有异常才会执行异常代码下所有代码，没有异常不会执行*/
      WHEN GLOBAL_ERROR_EXCEPTION THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
      WHEN OTHERS THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
           DBMS_OUTPUT.PUT_LINE(GLOBAL_OUT_RETURN);
END PRO_REPORT_TEAM_PERFORMANCE ;
END PKG_REPORT_TEAM_PERFORMANCE;
/
