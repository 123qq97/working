CREATE PACKAGE BODY PKG_REPORT_DEPT_PERFORMANCE
AS  PROCEDURE PRO_REPORT_DEPT_PERFORMANCE
(
       IN_QUERY_MONTH IN VARCHAR,       /*输入-月份YYYY-mm*/
       IN_LONG_NUMBERS IN VARCHAR,      /*输入-长编码，多个用逗号隔开*/
       OUT_DATASET OUT GET_CURSOR       /*输出-结果集*/
)
IS
   V_SQL  CLOB;                         /*变量-执行总SQL*/
   V_WITH_SQL  CLOB;                        /*变量-临时变量视图SQL*/
   V_ROW_RESULT_SQL  CLOB;                  /*变量-行结果集SQL*/
   V_OUT_AVG_RESULT_SQL  CLOB;              /*变量-外单人均结果集SQL*/
   V_TOTAL_AVG_RESULT_SQL  CLOB;            /*变量-总业绩人均结果集SQL*/
   V_LEFT_AUTH_SQL CLOB;                   /*变量-LEFT JOIN权限表*/
   V_WHERE_AUTH_SQL CLOB;                   /*变量-权限条件*/
   GLOBAL_OUT_RETURN VARCHAR2(1000);      /*异常描述*/
   GLOBAL_ERROR_EXCEPTION EXCEPTION;      /*申明异常*/
   GLOBAL_ERROR_CODE      NUMBER;         /*异常编码*/
   GLOBAL_ERROR_MSG       VARCHAR2(1000); /*异常信息*/
   GLOBAL_FLAG           VARCHAR2(10);    /*标记*/
BEGIN
   DBMS_OUTPUT.ENABLE(BUFFER_SIZE => NULL);
   V_WITH_SQL := '
              WITH
                /*权限*/
                V_T_AUTH AS (
                    SELECT  STR1 AS   LONG_NUMBER
                                FROM ( SELECT  DISTINCT
                                                SUBSTR(T.CA,INSTR(T.CA, '','', 1, C.LV) + 1,
                                                       INSTR(T.CA, '','', 1, C.LV + 1) -(INSTR(T.CA, '','', 1, C.LV) + 1)) AS STR1
                                       FROM (SELECT '','' || STR || '','' AS CA,LENGTH(STR || '','') -NVL(LENGTH(REPLACE(STR, '','')), 0) AS CNT FROM ((SELECT  '''|| IN_LONG_NUMBERS ||''' AS STR FROM DUAL))) T,
                                            (SELECT LEVEL LV FROM DUAL CONNECT BY LEVEL <= 1000) C
                                       WHERE C.LV <= T.CNT )),
             /*有权限的部门*/
             V_T_DEPT AS (
                 SELECT DISTINCT D.SUB_COMPANY_NAME,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID
                 FROM V_ERP_ORG_BUSS_DEPT D
                        INNER JOIN V_T_AUTH ON INSTR(D.DEPT_LONG_NUMBER, V_T_AUTH.LONG_NUMBER)> 0 ),
             /*有权限的部门+人员*/
             V_T_DEPT_PERSON AS (
                 SELECT D.SUB_COMPANY_NAME,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID , P.FID AS PERSON_ID, P.FNAME AS PERSON_NAME, P.FPOSITION_NAME, P.FJOIN_DATE , P.FLEAVE_DATE
                 FROM V_T_DEPT D
                     LEFT JOIN V_ERP_ORG_ALL_PERSON P ON P.FORG_ID = D.DEPT_ID
                 WHERE TO_CHAR(P.FJOIN_DATE,''YYYY-MM'') <= ''' || IN_QUERY_MONTH || '''
                       AND ( TO_CHAR(P.FLEAVE_DATE,''YYYY-MM'') >= ''' || IN_QUERY_MONTH || '''  OR P.FLEAVE_DATE is null)
             ),
             /*订单-月份*/
             V_T_ORDER AS (
                 SELECT DISTINCT V_ORDER.*
                 FROM V_ORDER_REPAYMENT_REDEEM V_ORDER
                     INNER JOIN V_T_DEPT_PERSON P ON P.PERSON_ID = V_ORDER.PARTNER_ID
                     WHERE V_ORDER.NOT_REDEEM_REPARYMENT_COUNT = 0 AND TO_CHAR(V_ORDER.FREDEEM_REPAMYTNT_DATE,''yyyy-mm'') = ''' || IN_QUERY_MONTH || ''' ),

            /**人员订单汇总-月份*/
            V_T_ORDER_PERSON_MONTH_SUM AS (
                 SELECT D.SUB_COMPANY_NAME,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID,
                   D.PERSON_ID,
                   COUNT(V_ORDER.FORDER_ID) AS TOTAL_COUNT,
                   SUM(V_ORDER.TOTAL_MONEY) AS TOTAL_MONEY,
                   /*额度*/
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' THEN 1 ELSE 0 END ) AS AMOUNT_TOTAL_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS AMOUNT_TOTAL_MONEY ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' AND V_ORDER.FGUARANTEE_TYPE = ''INTERNAL'' THEN 1 ELSE 0 END ) AS AMOUNT_IN_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' AND V_ORDER.FGUARANTEE_TYPE = ''INTERNAL'' THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS AMOUNT_IN_MONEY ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' AND V_ORDER.FGUARANTEE_TYPE != ''INTERNAL'' THEN 1 ELSE 0 END ) AS AMOUNT_OUT_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''AMOUNT'' AND V_ORDER.FGUARANTEE_TYPE != ''INTERNAL''  THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS AMOUNT_OUT_MONEY ,
                   /*现金*/
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' THEN 1 ELSE 0 END ) AS CASH_TOTAL_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS CASH_TOTAL_MONEY ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' AND V_ORDER.FGUARANTEE_TYPE = ''INTERNAL'' THEN 1 ELSE 0 END ) AS CASH_IN_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' AND V_ORDER.FGUARANTEE_TYPE = ''INTERNAL'' THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS CASH_IN_MONEY ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' AND V_ORDER.FGUARANTEE_TYPE != ''INTERNAL'' THEN 1 ELSE 0 END ) AS CASH_OUT_COUNT ,
                   SUM( CASE WHEN V_ORDER.FFUND_TYPE = ''CASH'' AND V_ORDER.FGUARANTEE_TYPE != ''INTERNAL''  THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS CASH_OUT_MONEY ,
                   /*非交易*/
                   SUM( CASE WHEN V_ORDER.FTRANSACTION_TYPE = ''NOT_TRANSACTION'' THEN 1 ELSE 0 END ) AS NOT_TRANSACTION_COUNT ,
                   SUM( CASE WHEN V_ORDER.FTRANSACTION_TYPE = ''NOT_TRANSACTION'' THEN V_ORDER.TOTAL_MONEY ELSE 0 END ) AS NOT_TRANSACTION_MONEY,
                   SUM( CASE WHEN V_ORDER.FTRANSACTION_TYPE = ''NOT_TRANSACTION'' THEN V_ORDER.FBILLING_TOTAL_MONEY ELSE 0 END ) AS NOT_TRANSACTION_BILLING_MONEY,
                   SUM( CASE WHEN V_ORDER.IS_OUT_BUSS = 1 THEN (NVL(V_ORDER.TOTAL_MONEY,0) * 0.4) ELSE 0 END) AS OUT_RECOMMEND_MONEY
              FROM V_T_ORDER V_ORDER
                   LEFT JOIN V_T_DEPT_PERSON D ON D.PERSON_ID = V_ORDER.PARTNER_ID
                   GROUP BY D.SUB_COMPANY_NAME,D.TEAM_NAME,D.DEPT_NAME,D.DEPT_ID, D.PERSON_ID),

            /**人员订单汇总-跨月退费*/
            V_T_REFUND_PERSON_MONTH_SUM AS (
               SELECT  V_REFUND.FMANAGER_ID AS PERSON_ID, SUM(V_REFUND.FAPPLY_REFUND_MONEY) AS SPAN_REFUND_MONEY FROM V_ORDER_REFUND_FEE V_REFUND
                   LEFT JOIN V_ORDER_REPAYMENT_REDEEM V_O_BEFORE ON V_O_BEFORE.FORDER_ID = V_REFUND.FORDER_ID
                        AND  V_O_BEFORE.NOT_REDEEM_REPARYMENT_COUNT = 0
                        AND TO_CHAR(V_O_BEFORE.FREDEEM_REPAMYTNT_DATE,''yyyy-mm'') < ''' || IN_QUERY_MONTH || '''
                   INNER JOIN V_T_DEPT_PERSON P ON P.PERSON_ID = V_REFUND.FMANAGER_ID
               WHERE TO_CHAR(V_REFUND.FREFUND_DATE,''yyyy-mm'') = ''' || IN_QUERY_MONTH || '''
               GROUP BY V_REFUND.FMANAGER_ID
            ),
            /**部门总人数*/
            DEPT_PERSON_SUM AS (
                SELECT SUB_COMPANY_NAME,TEAM_NAME,DEPT_NAME,DEPT_ID , COUNT(1) AS PERSON_COUNT FROM V_T_DEPT_PERSON D
                GROUP BY SUB_COMPANY_NAME,TEAM_NAME,DEPT_NAME,DEPT_ID
            ),
            /**部门订单汇总*/
            DEPT_ORDER_SUM AS (
                SELECT P.DEPT_ID , SUM(O.TOTAL_MONEY) AS TOTAL_MONEY,
                       NVL(SUM(O.AMOUNT_OUT_MONEY),0) + NVL(SUM(O.CASH_OUT_MONEY),0) - NVL(SUM(O.OUT_RECOMMEND_MONEY),0) - NVL(SUM(R.SPAN_REFUND_MONEY),0) AS TOTAL_SUB_MONEY ,
                       SUM(NVL(O.AMOUNT_OUT_MONEY,0) + NVL(O.CASH_OUT_MONEY,0)) AS TOTAL_OUT_MONEY
                FROM V_T_DEPT_PERSON P
                     LEFT JOIN V_T_ORDER_PERSON_MONTH_SUM O ON O.PERSON_ID = P.PERSON_ID
                     LEFT JOIN V_T_REFUND_PERSON_MONTH_SUM R ON R.PERSON_ID = P.PERSON_ID
                GROUP BY P.DEPT_ID
            )
   ';


   /*行结果集SQL*/
   V_ROW_RESULT_SQL :='
                    /* ========================================V_ROW_RESULT_SQL-BEGIN========================= */
                    SELECT
                       1 AS DATA_TYPE , ''行数据'' AS DATA_TYPE_NAME ,
                       P.SUB_COMPANY_NAME ,
                       P.TEAM_NAME ,
                       P.DEPT_NAME ,
                       P.DEPT_ID ,
                       P.PERSON_ID ,
                       P.PERSON_NAME AS CUSTOMER_NAME ,
                       TO_CHAR(P.FJOIN_DATE,''YYYY-MM-DD'') AS FJOIN_DATE ,
                       TO_CHAR(P.FLEAVE_DATE,''YYYY-MM-DD'') AS FLEAVE_DATE ,
                       P.FPOSITION_NAME AS FLEVEL,
                       ROW_NUMBER() OVER(PARTITION BY P.DEPT_ID ORDER BY NVL(ROW_DATA.TOTAL_MONEY,0) DESC ) AS DEPT_INDEX,
                       ROW_DATA.TOTAL_COUNT,
                       ROW_DATA.TOTAL_MONEY,
                       ROW_DATA.AMOUNT_TOTAL_COUNT , ROW_DATA.AMOUNT_TOTAL_MONEY,
                       ROW_DATA.AMOUNT_IN_COUNT , ROW_DATA.AMOUNT_IN_MONEY,
                       ROW_DATA.AMOUNT_OUT_COUNT , ROW_DATA.AMOUNT_OUT_MONEY,
                       ROW_DATA.CASH_TOTAL_COUNT , ROW_DATA.CASH_TOTAL_MONEY,
                       ROW_DATA.CASH_IN_COUNT , ROW_DATA.CASH_IN_MONEY,
                       ROW_DATA.CASH_OUT_COUNT , ROW_DATA.CASH_OUT_MONEY,
                       ROW_DATA.NOT_TRANSACTION_COUNT , ROW_DATA.NOT_TRANSACTION_MONEY,
                       ROW_DATA.NOT_TRANSACTION_BILLING_MONEY,
                       ROW_DATA.OUT_RECOMMEND_MONEY,
                       ROW_REFUND.SPAN_REFUND_MONEY
                    FROM  V_T_DEPT_PERSON P
                          LEFT JOIN V_T_ORDER_PERSON_MONTH_SUM  ROW_DATA ON P.PERSON_ID = ROW_DATA.PERSON_ID
                          LEFT JOIN V_T_REFUND_PERSON_MONTH_SUM ROW_REFUND ON ROW_REFUND.PERSON_ID = P.PERSON_ID
                        /* ========================================V_ROW_RESULT_SQL-END========================= */
                         ';

   /*外单人均结果集SQL*/
   V_OUT_AVG_RESULT_SQL :='
                          SELECT
                               2 AS DATA_TYPE , ''外单人均'' AS DATA_TYPE_NAME ,
                               DEPT_SUM.SUB_COMPANY_NAME ,
                               DEPT_SUM.TEAM_NAME ,
                               DEPT_SUM.DEPT_NAME ,
                               DEPT_SUM.DEPT_ID ,
                               NULL AS PERSON_ID ,
                               NULL AS CUSTOMER_NAME ,
                               NULL AS FJOIN_DATE ,
                               NULL AS FLEAVE_DATE ,
                               NULL AS FLEVEL ,
                               NULL AS  DEPT_INDEX,
                               NULL AS TOTAL_COUNT,
                               CASE WHEN DEPT_SUM.PERSON_COUNT > 0 THEN ROUND(ROW_OUT.TOTAL_OUT_MONEY  /  DEPT_SUM.PERSON_COUNT,2) ELSE 0 END AS TOTAL_MONEY,
                               NULL AS AMOUNT_TOTAL_COUNT , NULL AS AMOUNT_TOTAL_MONEY,
                               NULL AS AMOUNT_IN_COUNT , NULL AS AMOUNT_IN_MONEY,
                               NULL AS AMOUNT_OUT_COUNT , NULL AS AMOUNT_OUT_MONEY,
                               NULL AS CASH_TOTAL_COUNT , NULL AS CASH_TOTAL_MONEY,
                               NULL AS CASH_IN_COUNT , NULL AS CASH_IN_MONEY,
                               NULL AS CASH_OUT_COUNT , NULL AS CASH_OUT_MONEY,
                               NULL AS NOT_TRANSACTION_COUNT , NULL AS NOT_TRANSACTION_MONEY,
                               NULL AS NOT_TRANSACTION_BILLING_MONEY,
                               NULL AS SPAN_REFUND_MONEY,
                               NULL AS OUT_RECOMMEND_MONEY
                          FROM DEPT_ORDER_SUM ROW_OUT
                               RIGHT JOIN DEPT_PERSON_SUM DEPT_SUM ON DEPT_SUM.DEPT_ID = ROW_OUT.DEPT_ID
                     ';

   /*总业绩人均结果集SQL*/
   V_TOTAL_AVG_RESULT_SQL :='
                          SELECT
                               3 AS DATA_TYPE , ''总业绩人均'' AS DATA_TYPE_NAME ,
                               DEPT_SUM.SUB_COMPANY_NAME ,
                               DEPT_SUM.TEAM_NAME ,
                               DEPT_SUM.DEPT_NAME ,
                               DEPT_SUM.DEPT_ID ,
                               NULL AS PERSON_ID ,
                               NULL AS CUSTOMER_NAME ,
                               NULL AS FJOIN_DATE ,
                               NULL AS FLEAVE_DATE ,
                               NULL AS FLEVEL ,
                               NULL AS  DEPT_INDEX,
                               NULL AS TOTAL_COUNT,
                               CASE WHEN DEPT_SUM.PERSON_COUNT > 0 THEN ROUND(ROW_OUT.TOTAL_SUB_MONEY  /  DEPT_SUM.PERSON_COUNT,2) ELSE 0 END AS TOTAL_MONEY,
                               NULL AS AMOUNT_TOTAL_COUNT , NULL AS AMOUNT_TOTAL_MONEY,
                               NULL AS AMOUNT_IN_COUNT , NULL AS AMOUNT_IN_MONEY,
                               NULL AS AMOUNT_OUT_COUNT , NULL AS AMOUNT_OUT_MONEY,
                               NULL AS CASH_TOTAL_COUNT , NULL AS CASH_TOTAL_MONEY,
                               NULL AS CASH_IN_COUNT , NULL AS CASH_IN_MONEY,
                               NULL AS CASH_OUT_COUNT , NULL AS CASH_OUT_MONEY,
                               NULL AS NOT_TRANSACTION_COUNT , NULL AS NOT_TRANSACTION_MONEY,
                               NULL AS NOT_TRANSACTION_BILLING_MONEY,
                               NULL AS SPAN_REFUND_MONEY,
                               NULL AS OUT_RECOMMEND_MONEY
                          FROM DEPT_ORDER_SUM ROW_OUT
                               RIGHT JOIN DEPT_PERSON_SUM DEPT_SUM ON DEPT_SUM.DEPT_ID = ROW_OUT.DEPT_ID
                     ';

   /*执行总SQL*/
   V_SQL := V_WITH_SQL ||   ' '   ||  V_ROW_RESULT_SQL ||  ' UNION ALL ' || V_OUT_AVG_RESULT_SQL || ' UNION ALL ' || V_TOTAL_AVG_RESULT_SQL ;

   /*设置排序*/
   V_SQL := 'SELECT * FROM (' || V_SQL || ')  V_SQL ORDER BY SUB_COMPANY_NAME , TEAM_NAME , DEPT_ID , DATA_TYPE ,DEPT_INDEX ';

   DBMS_OUTPUT.PUT_LINE('执行总SQL:>>>>>>>==================');
   DBMS_OUTPUT.PUT_LINE(V_SQL);
   /*执行*/
   OPEN OUT_DATASET FOR V_SQL;
EXCEPTION
      /*异常捕捉，不要把有需要的代码放在异常捕捉后面，有异常才会执行异常代码下所有代码，没有异常不会执行*/
      WHEN GLOBAL_ERROR_EXCEPTION THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
      WHEN OTHERS THEN
           GLOBAL_ERROR_CODE := SQLCODE;
           GLOBAL_ERROR_MSG := SUBSTR(SQLERRM, 1, 200);
           GLOBAL_FLAG := 'false';
           GLOBAL_OUT_RETURN := 'GLOBAL_FLAG=' || GLOBAL_FLAG || ',GLOBAL_ERROR_CODE=' || GLOBAL_ERROR_CODE || ',GLOBAL_ERROR_MSG=' || GLOBAL_ERROR_MSG;
           DBMS_OUTPUT.PUT_LINE(GLOBAL_OUT_RETURN);
END PRO_REPORT_DEPT_PERFORMANCE ;
END PKG_REPORT_DEPT_PERFORMANCE;
/
